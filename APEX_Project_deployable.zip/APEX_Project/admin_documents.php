<?php
// Admin: review learner document uploads (approve / reject with a note).

require_once __DIR__ . '/includes/app.php';
require_once __DIR__ . '/includes/portal.php';
app_start();
require_admin();

$db = db_connect();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        flash_set('error', 'Your session expired. Please try again.');
    } elseif (isset($_POST['review_document'], $_POST['decision'])) {
        $documentId = (int) $_POST['review_document'];
        $decision = $_POST['decision'] === 'approve' ? 'Approved' : 'Rejected';
        $note = sanitize_string($_POST['review_note'] ?? '');

        if (portal_review_document($db, $documentId, $decision, $note)) {
            flash_set('success', 'Document ' . strtolower($decision) . '.');
        } else {
            flash_set('error', 'Could not update the document.');
        }
    }

    $statusQuery = isset($_POST['return_status']) ? '?status=' . urlencode($_POST['return_status']) : '';
    header('Location: ' . site_url('admin_documents.php' . $statusQuery));
    exit;
}

$statusFilter = $_GET['status'] ?? 'Pending';
if (!in_array($statusFilter, ['Pending', 'Approved', 'Rejected', 'All'], true)) {
    $statusFilter = 'Pending';
}
$documents = portal_get_all_documents($db, $statusFilter === 'All' ? null : $statusFilter);
?>
<?php render_head('Document Review'); ?>
<body class="admin-body">
  <?php render_admin_navigation(); ?>
  <div class="page-container">
    <?php render_flash_messages(); ?>
    <div class="section-header">
      <div>
        <h1>Learner Documents</h1>
        <p>Review onboarding documents and assignment submissions uploaded by learners.</p>
      </div>
      <div class="filter-tabs">
        <?php foreach (['Pending', 'Approved', 'Rejected', 'All'] as $filter): ?>
          <a href="<?php echo html_escape(site_url('admin_documents.php?status=' . $filter)); ?>"
             class="filter-tab<?php echo $statusFilter === $filter ? ' active' : ''; ?>"><?php echo $filter; ?></a>
        <?php endforeach; ?>
      </div>
    </div>

    <div class="course-card">
      <?php if (empty($documents)): ?>
        <p>No <?php echo $statusFilter === 'All' ? '' : strtolower($statusFilter) . ' '; ?>documents found.</p>
      <?php else: ?>
        <table class="course-table documents-table">
          <tr>
            <th>Learner</th>
            <th>Document</th>
            <th>Type</th>
            <th>Size</th>
            <th>Uploaded</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
          <?php foreach ($documents as $document): ?>
            <tr>
              <td>
                <?php echo html_escape($document['full_name'] ?: $document['username']); ?>
                <div class="muted"><?php echo html_escape($document['email'] ?? ''); ?></div>
              </td>
              <td>
                <?php echo html_escape($document['document_name']); ?>
                <?php if (!empty($document['review_note'])): ?>
                  <div class="review-note">Note: <?php echo html_escape($document['review_note']); ?></div>
                <?php endif; ?>
              </td>
              <td><?php echo html_escape($document['doc_type']); ?></td>
              <td><?php echo format_file_size((int) $document['file_size']); ?></td>
              <td><?php echo html_escape(date('d M Y H:i', strtotime($document['upload_date']))); ?></td>
              <td><span class="status-chip chip-<?php echo strtolower($document['status']); ?>"><?php echo html_escape($document['status']); ?></span></td>
              <td class="table-actions">
                <a class="btn btn-soft btn-small" href="<?php echo html_escape(site_url('download.php?type=document&id=' . (int) $document['id'])); ?>">Download</a>
                <?php if ($document['status'] === 'Pending'): ?>
                  <form method="post" class="review-form">
                    <?php echo csrf_input_field(); ?>
                    <input type="hidden" name="review_document" value="<?php echo (int) $document['id']; ?>">
                    <input type="hidden" name="return_status" value="<?php echo html_escape($statusFilter); ?>">
                    <input type="text" name="review_note" placeholder="Optional note for the learner" maxlength="255">
                    <button type="submit" name="decision" value="approve" class="btn btn-primary btn-small">Approve</button>
                    <button type="submit" name="decision" value="reject" class="btn btn-danger btn-small">Reject</button>
                  </form>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </table>
      <?php endif; ?>
    </div>

    <div class="info-panel">
      <h2>Review guidelines</h2>
      <ul>
        <li>Certified ID copies must be clearly legible and certified within the last 3 months.</li>
        <li>When rejecting a document, add a note so the learner knows what to fix before re-uploading.</li>
        <li>Documents contain personal information - handle them in line with POPIA and do not share them outside the programme.</li>
      </ul>
    </div>
  </div>
  <?php render_page_footer(); ?>
</body>
</html>
