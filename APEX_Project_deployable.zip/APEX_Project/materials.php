<?php
// Learning materials library: download study guides, slides and resources
// published by the training provider.

require_once __DIR__ . '/includes/app.php';
require_once __DIR__ . '/includes/portal.php';
require_once __DIR__ . '/includes/module_template.php';
app_start();
require_user();

$db = db_connect();
$userId = (int) $_SESSION['user_id'];

$materials = portal_get_materials_for_user($db, $userId);
$hasApproved = portal_user_has_approved_course($db, $userId);
$moduleTitles = array_map(fn ($m) => $m['title'], get_module_metadata());

$grouped = ['general' => []];
foreach ($materials as $material) {
    $key = $material['module_number'] ? 'module' . (int) $material['module_number'] : 'general';
    $grouped[$key][] = $material;
}
?>
<?php render_head('Learning Materials'); ?>
<body>
  <?php render_navigation(); ?>
  <div class="page-container">
    <?php render_flash_messages(); ?>
    <div class="section-header">
      <div>
        <h1>Learning Materials</h1>
        <p>Download the study guides, slides and exercises for your course. All files are also available on your phone.</p>
      </div>
    </div>

    <?php if (!$hasApproved): ?>
      <div class="alert-box">
        <strong>Note:</strong> Course-specific materials become available once your enrollment is approved.
        General programme resources are listed below.
      </div>
    <?php endif; ?>

    <?php if (empty($materials)): ?>
      <div class="info-panel">
        <h2>No materials published yet</h2>
        <p>Your training provider has not uploaded any learning materials yet. Please check back soon, or contact your
           coordinator if you are expecting study guides for your modules.</p>
      </div>
    <?php else: ?>
      <?php if (!empty($grouped['general'])): ?>
        <div class="course-card">
          <h2>General programme resources</h2>
          <ul class="material-list">
            <?php foreach ($grouped['general'] as $material): ?>
              <li class="material-item">
                <div>
                  <strong><?php echo html_escape($material['title']); ?></strong>
                  <?php if (!empty($material['description'])): ?>
                    <p class="material-description"><?php echo html_escape($material['description']); ?></p>
                  <?php endif; ?>
                  <span class="material-meta">
                    <?php echo html_escape($material['subject_name'] ?? 'All courses'); ?> &middot;
                    <?php echo html_escape($material['original_name']); ?> &middot;
                    <?php echo format_file_size((int) $material['file_size']); ?> &middot;
                    <?php echo html_escape(date('d M Y', strtotime($material['upload_date']))); ?>
                  </span>
                </div>
                <a class="btn btn-primary" href="<?php echo html_escape(site_url('download.php?type=material&id=' . (int) $material['id'])); ?>">Download</a>
              </li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>

      <?php for ($moduleNumber = 1; $moduleNumber <= TOTAL_MODULES; $moduleNumber++): ?>
        <?php $key = 'module' . $moduleNumber; ?>
        <?php if (!empty($grouped[$key])): ?>
          <div class="course-card">
            <h2>Module <?php echo $moduleNumber; ?>: <?php echo html_escape($moduleTitles[$moduleNumber] ?? ''); ?></h2>
            <ul class="material-list">
              <?php foreach ($grouped[$key] as $material): ?>
                <li class="material-item">
                  <div>
                    <strong><?php echo html_escape($material['title']); ?></strong>
                    <?php if (!empty($material['description'])): ?>
                      <p class="material-description"><?php echo html_escape($material['description']); ?></p>
                    <?php endif; ?>
                    <span class="material-meta">
                      <?php echo html_escape($material['original_name']); ?> &middot;
                      <?php echo format_file_size((int) $material['file_size']); ?> &middot;
                      <?php echo html_escape(date('d M Y', strtotime($material['upload_date']))); ?>
                    </span>
                  </div>
                  <a class="btn btn-primary" href="<?php echo html_escape(site_url('download.php?type=material&id=' . (int) $material['id'])); ?>">Download</a>
                </li>
              <?php endforeach; ?>
            </ul>
          </div>
        <?php endif; ?>
      <?php endfor; ?>
    <?php endif; ?>

    <div class="info-panel">
      <h2>Data-friendly tips</h2>
      <ul>
        <li>Download materials over Wi-Fi where possible to save mobile data.</li>
        <li>Files stay available here for the duration of your learnership - you can re-download them at any time.</li>
        <li>If a download fails, refresh the page and try again, or contact your coordinator.</li>
      </ul>
    </div>
  </div>
  <?php render_page_footer(); ?>
</body>
</html>
