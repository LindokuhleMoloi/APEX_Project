<?php
require_once __DIR__ . '/includes/app.php';
require_once __DIR__ . '/includes/portal.php';
app_start();
require_user();

$mysqli = db_connect();
$user_id = (int) $_SESSION['user_id'];

// Handle enrollment requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['enroll_subject_id'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        flash_set('error', 'Your session expired. Please try again.');
    } else {
        $subjectId = (int) $_POST['enroll_subject_id'];
        $stmt = $mysqli->prepare("SELECT email FROM users WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        $email = $stmt->get_result()->fetch_assoc()['email'] ?? null;
        $stmt->close();

        $result = portal_request_enrollment($mysqli, $user_id, $subjectId, $email);
        if ($result['ok']) {
            flash_set('success', 'Enrollment request submitted. The training provider will review and approve it.');
        } else {
            flash_set('error', $result['error']);
        }
    }
    header('Location: ' . site_url('courses.php'));
    exit;
}

$courses = portal_get_courses($mysqli);
$registrations = [];
foreach (portal_get_user_registrations($mysqli, $user_id) as $registration) {
    $registrations[(int) $registration['subject_id']] = $registration;
}
$hasApproved = portal_user_has_approved_course($mysqli, $user_id);
?>
<?php render_head('Courses'); ?>
<body>
  <?php render_navigation(); ?>
  <div class="page-container course-page">
    <?php render_flash_messages(); ?>
    <div class="courses-header">
      <div>
        <h1>Courses</h1>
        <p>SETA-accredited qualifications available on this learnership programme.</p>
      </div>
      <?php if ($hasApproved): ?>
        <div class="course-actions">
          <a href="<?php echo html_escape(site_url('modules/module1/index.php')); ?>" class="btn btn-primary">Continue your course</a>
        </div>
      <?php endif; ?>
    </div>

    <div class="course-grid">
      <?php foreach ($courses as $course): ?>
        <?php $registration = $registrations[(int) $course['id']] ?? null; ?>
        <article class="course-detail-card">
          <div class="course-detail-head">
            <h2><?php echo html_escape($course['name']); ?></h2>
            <?php if ($registration): ?>
              <span class="status-chip chip-<?php echo strtolower($registration['status']); ?>"><?php echo html_escape($registration['status']); ?></span>
            <?php else: ?>
              <span class="status-chip chip-none">Not enrolled</span>
            <?php endif; ?>
          </div>

          <p class="course-description"><?php echo html_escape($course['description'] ?? ''); ?></p>

          <dl class="course-facts">
            <div><dt>NQF level</dt><dd><?php echo html_escape((string) ($course['nqf_level'] ?? '-')); ?></dd></div>
            <div><dt>SAQA ID</dt><dd><?php echo html_escape($course['saqa_id'] ?? '-'); ?></dd></div>
            <div><dt>Credits</dt><dd><?php echo html_escape((string) ($course['credits'] ?? '-')); ?></dd></div>
            <div><dt>Duration</dt><dd><?php echo $course['duration_months'] ? (int) $course['duration_months'] . ' months' : '-'; ?></dd></div>
            <div><dt>SETA</dt><dd><?php echo html_escape($course['seta'] ?? '-'); ?></dd></div>
          </dl>

          <div class="module-actions">
            <?php if ($registration && $registration['status'] === 'Approved'): ?>
              <a href="<?php echo html_escape(site_url('modules/module1/index.php')); ?>" class="btn btn-primary">Continue learning</a>
              <a href="<?php echo html_escape(site_url('materials.php')); ?>" class="btn btn-soft">Course materials</a>
            <?php elseif ($registration && $registration['status'] === 'Pending'): ?>
              <span class="course-label">Waiting for approval (requested <?php echo html_escape(date('d M Y', strtotime($registration['registration_date']))); ?>)</span>
            <?php elseif ($registration && $registration['status'] === 'Rejected'): ?>
              <span class="course-label">Registration rejected &ndash; contact your training coordinator.</span>
            <?php else: ?>
              <form method="post" class="inline-form">
                <?php echo csrf_input_field(); ?>
                <input type="hidden" name="enroll_subject_id" value="<?php echo (int) $course['id']; ?>">
                <button type="submit" class="btn btn-primary">Request enrollment</button>
              </form>
            <?php endif; ?>
          </div>
        </article>
      <?php endforeach; ?>
    </div>

    <div class="alert-box course-info-card">
      <h2>About learnerships</h2>
      <p>A learnership is a structured learning programme that combines theory with practical workplace experience,
         registered with a SETA and leading to an NQF qualification. Your host employer supports the programme as part of
         its B-BBEE skills development commitment, and you build a nationally recognised qualification while you work.</p>
      <p>Once your enrollment is approved you will see the full module path on the home page, with materials, quizzes and
         progress tracking for your qualification.</p>
    </div>
  </div>
  <?php render_page_footer(); ?>
</body>
</html>
