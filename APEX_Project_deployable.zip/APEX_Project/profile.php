<?php
require_once __DIR__ . '/includes/app.php';
require_once __DIR__ . '/includes/portal.php';
app_start();
require_user();

$mysqli = db_connect();
$user_id = (int) $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        flash_set('error', 'Your session expired. Please try again.');
        header('Location: ' . site_url('profile.php'));
        exit;
    }

    if (isset($_POST['update_profile'])) {
        $full_name = sanitize_string($_POST['full_name'] ?? '');
        $email = sanitize_string($_POST['email'] ?? '');
        $phone = sanitize_string($_POST['phone'] ?? '');
        $theme = in_array($_POST['theme'] ?? '', ['default', 'soft', 'dark'], true) ? $_POST['theme'] : 'default';

        if (!$full_name || !$email) {
            flash_set('error', 'Please provide both your full name and email.');
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            flash_set('error', 'Please enter a valid email address.');
        } else {
            $stmt = $mysqli->prepare("UPDATE users SET full_name = ?, email = ?, phone = ?, theme = ? WHERE id = ?");
            $stmt->bind_param('ssssi', $full_name, $email, $phone, $theme, $user_id);
            if ($stmt->execute()) {
                $_SESSION['full_name'] = $full_name;
                $_SESSION['profile_theme'] = $theme;
                flash_set('success', 'Profile updated successfully.');
            } else {
                flash_set('error', 'Unable to save changes. Please try again.');
            }
            $stmt->close();
        }

        // Optional avatar upload alongside the profile update
        if (!empty($_FILES['avatar_file']['name'])) {
            $stored = handle_file_upload($_FILES['avatar_file'], 'avatars', ALLOWED_AVATAR_EXTENSIONS, 4 * 1024 * 1024);
            if ($stored['ok']) {
                $stmt = $mysqli->prepare("SELECT avatar_path FROM users WHERE id = ?");
                $stmt->bind_param('i', $user_id);
                $stmt->execute();
                $previous = $stmt->get_result()->fetch_assoc()['avatar_path'] ?? null;
                $stmt->close();

                $stmt = $mysqli->prepare("UPDATE users SET avatar_path = ? WHERE id = ?");
                $stmt->bind_param('si', $stored['path'], $user_id);
                $stmt->execute();
                $stmt->close();

                if ($previous) {
                    @unlink(UPLOADS_DIR . '/' . $previous);
                }
                flash_set('success', 'Profile photo updated.');
            } else {
                flash_set('error', 'Avatar: ' . $stored['error']);
            }
        }
    } elseif (isset($_POST['change_password'])) {
        $current = $_POST['current_password'] ?? '';
        $new = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_new_password'] ?? '';

        $stmt = $mysqli->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        $currentHash = $stmt->get_result()->fetch_assoc()['password'] ?? '';
        $stmt->close();

        if (!password_verify($current, $currentHash)) {
            flash_set('error', 'Your current password is incorrect.');
        } elseif (strlen($new) < 8) {
            flash_set('error', 'The new password must be at least 8 characters long.');
        } elseif ($new !== $confirm) {
            flash_set('error', 'The new passwords do not match.');
        } else {
            $newHash = password_hash($new, PASSWORD_DEFAULT);
            $stmt = $mysqli->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->bind_param('si', $newHash, $user_id);
            $stmt->execute();
            $stmt->close();
            flash_set('success', 'Password changed successfully.');
        }
    }

    header('Location: ' . site_url('profile.php'));
    exit;
}

$stmt = $mysqli->prepare(
    "SELECT u.username, u.email, u.full_name, u.phone, u.id_number, u.avatar_path, u.theme, u.created_at,
            s.name AS subject_name, r.status, r.registration_date
     FROM users u
     LEFT JOIN registrations r ON u.id = r.user_id
     LEFT JOIN subjects s ON r.subject_id = s.id
     WHERE u.id = ?
     ORDER BY (r.status = 'Approved') DESC
     LIMIT 1");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$profile = $stmt->get_result()->fetch_assoc();
$stmt->close();

$username = $profile['username'] ?? $_SESSION['username'] ?? 'Student';
$displayName = $profile['full_name'] ?: $username;
$theme = $profile['theme'] ?: ($_SESSION['profile_theme'] ?? 'default');
$_SESSION['profile_theme'] = $theme;
$avatarInitials = strtoupper(substr($displayName, 0, 1));
$themeClass = 'theme-' . ($theme === 'soft' ? 'soft' : ($theme === 'dark' ? 'dark' : 'default'));
$hasAvatar = !empty($profile['avatar_path']);
?>
<?php render_head('Profile'); ?>
<body class="<?php echo html_escape($themeClass); ?>">
  <?php render_navigation(); ?>
  <div class="page-container">
    <?php render_flash_messages(); ?>
    <div class="avatar-section">
      <?php if ($hasAvatar): ?>
        <img class="avatar-image" src="<?php echo html_escape(site_url('download.php?type=avatar&id=' . $user_id)); ?>" alt="Profile photo of <?php echo html_escape($displayName); ?>">
      <?php else: ?>
        <div class="avatar-placeholder"><?php echo html_escape($avatarInitials); ?></div>
      <?php endif; ?>
      <div>
        <h1>Welcome, <?php echo html_escape($displayName); ?></h1>
        <p>Manage your personal details, profile photo, portal theme and password.</p>
        <p><strong>Registered Course:</strong> <?php echo html_escape($profile['subject_name'] ?? 'No course registered'); ?></p>
      </div>
    </div>

    <div class="profile-card">
      <h2>Edit Your Details</h2>
      <form method="post" enctype="multipart/form-data">
        <?php echo csrf_input_field(); ?>
        <div class="form-grid">
          <div class="form-group">
            <label for="full_name">Full name</label>
            <input type="text" id="full_name" name="full_name" value="<?php echo html_escape($profile['full_name'] ?? ''); ?>" required>
          </div>
          <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" value="<?php echo html_escape($profile['email'] ?? ''); ?>" required>
          </div>
        </div>

        <div class="form-grid">
          <div class="form-group">
            <label for="phone">Cellphone number</label>
            <input type="tel" id="phone" name="phone" value="<?php echo html_escape($profile['phone'] ?? ''); ?>" placeholder="e.g. 072 123 4567">
          </div>
          <div class="form-group">
            <label for="theme">Portal Theme</label>
            <select id="theme" name="theme">
              <option value="default"<?php echo $theme === 'default' ? ' selected' : ''; ?>>Default</option>
              <option value="soft"<?php echo $theme === 'soft' ? ' selected' : ''; ?>>Soft Blue</option>
              <option value="dark"<?php echo $theme === 'dark' ? ' selected' : ''; ?>>Dark Mode</option>
            </select>
          </div>
        </div>

        <div class="form-group file-upload">
          <label for="avatar_file">Profile photo</label>
          <input type="file" id="avatar_file" name="avatar_file" accept=".png,.jpg,.jpeg,.gif">
          <small>PNG, JPG or GIF up to 4 MB.</small>
        </div>

        <button type="submit" name="update_profile" value="1" class="btn btn-primary">Save Changes</button>
      </form>
    </div>

    <div class="profile-card">
      <h2>Change Password</h2>
      <form method="post">
        <?php echo csrf_input_field(); ?>
        <div class="form-grid">
          <div class="form-group">
            <label for="current_password">Current password</label>
            <input type="password" id="current_password" name="current_password" autocomplete="current-password" required>
          </div>
          <div class="form-group">
            <label for="new_password">New password <span class="hint">(min 8 characters)</span></label>
            <input type="password" id="new_password" name="new_password" minlength="8" autocomplete="new-password" required>
          </div>
          <div class="form-group">
            <label for="confirm_new_password">Confirm new password</label>
            <input type="password" id="confirm_new_password" name="confirm_new_password" minlength="8" autocomplete="new-password" required>
          </div>
        </div>
        <button type="submit" name="change_password" value="1" class="btn btn-secondary">Change password</button>
      </form>
    </div>

    <div class="course-card">
      <h2>Account Information</h2>
      <dl class="profile-info">
        <dt>Username</dt>
        <dd><?php echo html_escape($username); ?></dd>
        <dt>Full name</dt>
        <dd><?php echo html_escape($profile['full_name'] ?? 'Not provided'); ?></dd>
        <dt>Email</dt>
        <dd><?php echo html_escape($profile['email'] ?? 'Not provided'); ?></dd>
        <dt>Cellphone</dt>
        <dd><?php echo html_escape($profile['phone'] ?? 'Not provided'); ?></dd>
        <dt>SA ID number</dt>
        <dd><?php echo $profile['id_number'] ? html_escape(substr($profile['id_number'], 0, 6) . '*******') : 'Not provided'; ?></dd>
        <dt>Registration Status</dt>
        <dd><?php echo html_escape($profile['status'] ?? 'Not registered'); ?></dd>
        <dt>Registration Date</dt>
        <dd><?php echo html_escape($profile['registration_date'] ?? '-'); ?></dd>
        <dt>Member since</dt>
        <dd><?php echo html_escape($profile['created_at'] ? date('d M Y', strtotime($profile['created_at'])) : '-'); ?></dd>
      </dl>
    </div>

    <div class="info-panel">
      <h2>Your privacy (POPIA)</h2>
      <ul>
        <li>Your personal information is used only for learnership administration, SETA registration and B-BBEE skills development reporting.</li>
        <li>Your ID number is partially hidden on screen and never shared with other learners.</li>
        <li>To correct or remove your information, contact your training coordinator.</li>
      </ul>
    </div>
  </div>
  <?php render_page_footer(); ?>
</body>
</html>
