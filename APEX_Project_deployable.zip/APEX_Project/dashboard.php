<?php
// dashboard.php - Admin overview: programme statistics, pending course
// registrations and admin account management.

require_once __DIR__ . '/includes/app.php';
require_once __DIR__ . '/includes/portal.php';
app_start();
require_admin();

$conn = db_connect();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        flash_set('error', 'Your session expired. Please try again.');
        header('Location: ' . site_url('dashboard.php'));
        exit;
    }

    // Approve / reject course registrations
    if (isset($_POST['action'], $_POST['request_id'])) {
        $request_id = (int) $_POST['request_id'];
        $action = $_POST['action'] === 'accept' ? 'Approved' : 'Rejected';
        $stmt = $conn->prepare("UPDATE registrations SET status = ?, decided_at = NOW() WHERE id = ?");
        $stmt->bind_param('si', $action, $request_id);
        $stmt->execute();
        $stmt->close();

        // Invalidate the learner's cached course list
        $stmt = $conn->prepare("SELECT user_id FROM registrations WHERE id = ?");
        $stmt->bind_param('i', $request_id);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($row) {
            cache_forget('subjects_for_user_' . (int) $row['user_id']);
        }

        flash_set('success', 'Registration ' . strtolower($action) . '.');
    }

    // Create a new admin account (admin-only - replaces the old public form)
    if (isset($_POST['create_admin'])) {
        $new_username = sanitize_string($_POST['new_username'] ?? '');
        $new_password = $_POST['new_password'] ?? '';

        if (!$new_username || strlen($new_password) < 8) {
            flash_set('error', 'Provide a username and a password of at least 8 characters.');
        } else {
            $stmt = $conn->prepare("SELECT id FROM admin WHERE username = ?");
            $stmt->bind_param('s', $new_username);
            $stmt->execute();
            $stmt->store_result();
            $exists = $stmt->num_rows > 0;
            $stmt->close();

            if ($exists) {
                flash_set('error', 'That admin username already exists.');
            } else {
                $hash = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("INSERT INTO admin (username, password) VALUES (?, ?)");
                $stmt->bind_param('ss', $new_username, $hash);
                $stmt->execute();
                $stmt->close();
                flash_set('success', 'Admin account "' . $new_username . '" created.');
            }
        }
    }

    header('Location: ' . site_url('dashboard.php'));
    exit;
}

$stats = portal_admin_stats($conn);

$sql = "SELECT cr.id, cr.status, cr.registration_date, u.id AS user_id, u.email AS email,
               u.username AS name, u.full_name, s.name AS course_name
        FROM registrations cr
        JOIN users u ON cr.user_id = u.id
        JOIN subjects s ON cr.subject_id = s.id
        WHERE cr.status = 'Pending'
        ORDER BY cr.registration_date ASC";
$pending = $conn->query($sql)->fetch_all(MYSQLI_ASSOC);

$recentAttempts = portal_get_all_quiz_attempts($conn);
$recentAttempts = array_slice($recentAttempts, 0, 8);
?>
<?php render_head('Admin Dashboard'); ?>
<body class="admin-body">
  <?php render_admin_navigation(); ?>
  <div class="page-container">
    <?php render_flash_messages(); ?>
    <div class="section-header">
      <div>
        <h1>Admin Dashboard</h1>
        <p>Signed in as <strong><?php echo html_escape($_SESSION['admin_username'] ?? 'admin'); ?></strong>. Programme overview and pending actions.</p>
      </div>
    </div>

    <div class="stat-grid">
      <div class="stat-card"><span class="stat-number"><?php echo $stats['learners']; ?></span><span class="stat-label">Registered learners</span></div>
      <div class="stat-card<?php echo $stats['pending_registrations'] > 0 ? ' stat-attention' : ''; ?>"><span class="stat-number"><?php echo $stats['pending_registrations']; ?></span><span class="stat-label">Pending registrations</span></div>
      <div class="stat-card"><span class="stat-number"><?php echo $stats['approved_registrations']; ?></span><span class="stat-label">Approved enrollments</span></div>
      <div class="stat-card<?php echo $stats['pending_documents'] > 0 ? ' stat-attention' : ''; ?>"><span class="stat-number"><?php echo $stats['pending_documents']; ?></span><span class="stat-label">Documents to review</span></div>
      <div class="stat-card"><span class="stat-number"><?php echo $stats['materials']; ?></span><span class="stat-label">Learning materials</span></div>
      <div class="stat-card"><span class="stat-number"><?php echo $stats['quiz_attempts']; ?></span><span class="stat-label">Quiz attempts</span></div>
      <div class="stat-card"><span class="stat-number"><?php echo $stats['pass_rate']; ?>%</span><span class="stat-label">Quiz pass rate</span></div>
    </div>

    <div class="course-card">
      <h2>Pending Course Registration Requests</h2>
      <?php if (empty($pending)): ?>
        <p>No pending requests - all caught up! &#127881;</p>
      <?php else: ?>
        <table class="course-table">
          <tr>
            <th>Learner</th>
            <th>Email</th>
            <th>Course</th>
            <th>Requested</th>
            <th>Action</th>
          </tr>
          <?php foreach ($pending as $row): ?>
            <tr>
              <td><?php echo html_escape($row['full_name'] ?: $row['name']); ?> <span class="muted">(<?php echo html_escape($row['name']); ?>)</span></td>
              <td><?php echo html_escape($row['email'] ?? '-'); ?></td>
              <td><?php echo html_escape($row['course_name']); ?></td>
              <td><?php echo html_escape(date('d M Y', strtotime($row['registration_date']))); ?></td>
              <td class="table-actions">
                <form method="post" class="inline-form">
                  <?php echo csrf_input_field(); ?>
                  <input type="hidden" name="request_id" value="<?php echo (int) $row['id']; ?>">
                  <button type="submit" name="action" value="accept" class="btn btn-primary btn-small">Approve</button>
                  <button type="submit" name="action" value="reject" class="btn btn-danger btn-small">Reject</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </table>
      <?php endif; ?>
    </div>

    <div class="dashboard">
      <div class="main-content">
        <div class="course-card">
          <h2>Recent quiz activity</h2>
          <?php if (empty($recentAttempts)): ?>
            <p>No quiz attempts recorded yet.</p>
          <?php else: ?>
            <table class="course-table">
              <tr><th>Date</th><th>Learner</th><th>Module</th><th>Result</th></tr>
              <?php foreach ($recentAttempts as $attempt): ?>
                <tr>
                  <td><?php echo html_escape($attempt['attempted_at']); ?></td>
                  <td><?php echo html_escape($attempt['full_name'] ?: $attempt['username']); ?></td>
                  <td>Module <?php echo (int) $attempt['module_number']; ?></td>
                  <td><?php echo number_format((float) $attempt['percent'], 0); ?>% <?php echo ((int) $attempt['passed']) === 1 ? '&#9989;' : '&#10060;'; ?></td>
                </tr>
              <?php endforeach; ?>
            </table>
            <p><a href="<?php echo html_escape(site_url('admin_results.php')); ?>" class="btn btn-soft">View all results</a></p>
          <?php endif; ?>
        </div>
      </div>

      <aside class="sidebar">
        <h3>Create admin account</h3>
        <p>Admin accounts can approve registrations, review documents and publish materials.</p>
        <form method="post">
          <?php echo csrf_input_field(); ?>
          <div class="form-group">
            <label for="new_username">Username</label>
            <input type="text" id="new_username" name="new_username" required>
          </div>
          <div class="form-group">
            <label for="new_password">Password <span class="hint">(min 8 characters)</span></label>
            <input type="password" id="new_password" name="new_password" minlength="8" required>
          </div>
          <button type="submit" name="create_admin" value="1" class="btn btn-primary">Create admin</button>
        </form>
      </aside>
    </div>
  </div>
  <?php render_page_footer(); ?>
</body>
</html>
