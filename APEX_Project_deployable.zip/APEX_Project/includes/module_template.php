<?php
// Module content, exit quizzes and the rendering pipeline for the
// six-module IT Foundations learning path shared by both qualifications.

require_once __DIR__ . '/app.php';
require_once __DIR__ . '/portal.php';

function get_module_metadata(): array
{
    return [
        1 => [
            'title' => 'Introduction to IT',
            'overview' => 'Build a strong foundation in IT literacy, hardware, software, and the role of technology in the workplace.',
            'goal' => 'Learn how computers, software, networks and data work together to support everyday tasks.',
            'topics' => [
                'IT concepts and terminology',
                'Difference between hardware and software',
                'File management and basic productivity tools',
            ],
            'learning_outcomes' => [
                'Understand basic IT terminology and systems.',
                'Recognise the role of hardware and software in daily computing.',
                'Explore the first steps in managing digital information securely.',
            ],
        ],
        2 => [
            'title' => 'Networking Basics',
            'overview' => 'Explore networking fundamentals, including how devices connect, communicate, and share information safely.',
            'goal' => 'Learn how computers and devices communicate over wired and wireless networks.',
            'topics' => [
                'Network topologies and connection types',
                'IP addressing, routers, and switches',
                'Basic network security and safe sharing',
            ],
            'learning_outcomes' => [
                'Describe common network architectures.',
                'Identify key networking hardware and protocols.',
                'Explain basic network security measures.',
            ],
        ],
        3 => [
            'title' => 'Programming Fundamentals',
            'overview' => 'Practice core programming concepts such as logic, variables, and syntax to build basic applications.',
            'goal' => 'Build confidence solving problems with programming logic and flow control.',
            'topics' => [
                'Variables, data types, and expressions',
                'Conditional statements and loops',
                'Debugging and testing basic code',
            ],
            'learning_outcomes' => [
                'Understand variables, loops, and conditionals.',
                'Write simple code to solve common problems.',
                'Trace program flow and identify errors.',
            ],
        ],
        4 => [
            'title' => 'Database Concepts',
            'overview' => 'Gain an introduction to databases, SQL queries, and how data is structured for applications.',
            'goal' => 'Learn how databases organize data and support applications through structured records.',
            'topics' => [
                'Database table design and data types',
                'Basic SELECT queries and filtering data',
                'How applications store and retrieve information',
            ],
            'learning_outcomes' => [
                'Understand tables, records, and fields.',
                'Learn the basics of SQL SELECT queries.',
                'Recognise common database terminology.',
            ],
        ],
        5 => [
            'title' => 'Web Development',
            'overview' => 'Study the essentials of web pages, including HTML structure, CSS styling, and how the web works.',
            'goal' => 'Learn how to create basic web pages using HTML, CSS, and modern design principles.',
            'topics' => [
                'HTML page structure and semantic tags',
                'CSS styling and responsive layouts',
                'Introduction to web page workflows',
            ],
            'learning_outcomes' => [
                'Understand HTML and CSS basics.',
                'Learn how web pages are structured and styled.',
                'Recognise the web development workflow.',
            ],
        ],
        6 => [
            'title' => 'Cybersecurity Essentials',
            'overview' => 'Learn how to protect yourself and your data using strong passwords, secure practices, and awareness of common cyber threats.',
            'goal' => 'Build habits that reduce risk and improve security when using computers and the internet.',
            'topics' => [
                'Common cyber threats, such as phishing and malware',
                'Best practices for strong passwords and account protection',
                'Safe browsing and data privacy awareness',
            ],
            'learning_outcomes' => [
                'Identify common cyber threats and attacks.',
                'Use strong passwords and safe online habits.',
                'Understand the importance of data privacy and protection.',
            ],
        ],
    ];
}

/**
 * Quiz questions per module. 'answer' is the index of the correct option;
 * grading happens server side only.
 */
function get_quiz_questions(): array
{
    return [
        1 => [
            [
                'question' => 'Which component is considered software?',
                'options' => ['Operating system', 'Keyboard', 'Hard drive'],
                'answer' => 0,
            ],
            [
                'question' => 'Which of the following is not a hardware device?',
                'options' => ['Monitor', 'Application', 'Mouse'],
                'answer' => 1,
            ],
            [
                'question' => 'What is the best practice for saving files?',
                'options' => ['Save in random folders', 'Use descriptive names and organised folders', 'Never save'],
                'answer' => 1,
            ],
        ],
        2 => [
            [
                'question' => 'What does IP stand for?',
                'options' => ['Internet Protocol', 'Internal Process', 'Interface Port'],
                'answer' => 0,
            ],
            [
                'question' => 'Which device forwards data between networks?',
                'options' => ['Switch', 'Router', 'Monitor'],
                'answer' => 1,
            ],
            [
                'question' => 'What should you use to protect your home network?',
                'options' => ['Public Wi-Fi', 'Strong password and encryption', 'Leave all settings open'],
                'answer' => 1,
            ],
        ],
        3 => [
            [
                'question' => 'What symbol is commonly used for assignment in many languages?',
                'options' => ['==', '=', '!='],
                'answer' => 1,
            ],
            [
                'question' => 'Which statement repeats a block of code while a condition is true?',
                'options' => ['if', 'for', 'return'],
                'answer' => 1,
            ],
            [
                'question' => 'Which concept helps your program decide between different options?',
                'options' => ['Loop', 'Condition', 'Variable'],
                'answer' => 1,
            ],
        ],
        4 => [
            [
                'question' => 'What is a row in a database table?',
                'options' => ['A single record', 'The database engine', 'A query'],
                'answer' => 0,
            ],
            [
                'question' => 'Which SQL keyword retrieves data from a table?',
                'options' => ['DELETE', 'SELECT', 'INSERT'],
                'answer' => 1,
            ],
            [
                'question' => 'What identifies a unique record in a table?',
                'options' => ['Primary key', 'Password', 'Folder name'],
                'answer' => 0,
            ],
        ],
        5 => [
            [
                'question' => 'What does HTML stand for?',
                'options' => ['Hypertext Markup Language', 'Hot Text Management Language', 'Hyperlink Model Language'],
                'answer' => 0,
            ],
            [
                'question' => 'Which element adds a paragraph in HTML?',
                'options' => ['<p>', '<div>', '<img>'],
                'answer' => 0,
            ],
            [
                'question' => 'What CSS property changes text color?',
                'options' => ['font-size', 'color', 'background'],
                'answer' => 1,
            ],
        ],
        6 => [
            [
                'question' => 'Which password is strongest?',
                'options' => ['password123', 'P@55w0rd!', '123456'],
                'answer' => 1,
            ],
            [
                'question' => 'What is phishing?',
                'options' => ['A harmless email newsletter', 'A deceptive message trying to steal information', 'A software update'],
                'answer' => 1,
            ],
            [
                'question' => 'What should you do before clicking a link in an unknown email?',
                'options' => ['Click immediately', 'Verify the sender and check the URL', 'Forward it to friends'],
                'answer' => 1,
            ],
        ],
    ];
}

/**
 * Redirects to the locked page when the drip rule says this module
 * is not open for the current learner yet.
 */
function require_module_unlocked(int $moduleId, string $content = 'module'): void
{
    $db = db_connect();
    $userId = (int) ($_SESSION['user_id'] ?? 0);
    if (!portal_is_module_unlocked($db, $userId, $moduleId)) {
        $suffix = $content === 'quiz' ? '&content=quiz' : '';
        header('Location: ' . site_url('locked_module.php?module=' . $moduleId . $suffix));
        exit;
    }
}

function render_module_navigation(int $moduleId, string $context = 'module'): void
{
    $db = db_connect();
    $userId = (int) ($_SESSION['user_id'] ?? 0);
    $passed = portal_get_passed_modules($db, $userId);
    $modules = get_module_metadata();

    echo '<nav class="module-tabs" aria-label="Modules">';
    echo '<span>Modules:</span>';
    foreach ($modules as $id => $module) {
        $active = $id === $moduleId ? ' active' : '';
        $unlocked = portal_is_module_unlocked($db, $userId, $id);
        $icon = isset($passed[$id]) ? ' &#10003;' : (!$unlocked ? ' &#128274;' : '');
        $target = $unlocked
            ? ($context === 'quiz' ? site_url("modules/module{$id}/quiz.php") : site_url("modules/module{$id}/index.php"))
            : site_url('locked_module.php?module=' . $id);
        $lockedClass = $unlocked ? '' : ' module-tab-locked';
        echo '<a href="' . html_escape($target) . '" class="module-tab' . $active . $lockedClass . '">Module ' . $id . $icon . '</a>';
    }
    echo '<a href="' . html_escape(site_url('index.php')) . '" class="btn btn-soft module-nav-return">Course path</a>';
    echo '</nav>';
}

function render_module_page(int $moduleId): void
{
    $modules = get_module_metadata();
    if (!isset($modules[$moduleId])) {
        http_response_code(404);
        echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>Module not found</title></head><body><h1>Module not found</h1><p>The requested module does not exist.</p></body></html>';
        return;
    }

    require_module_unlocked($moduleId);

    $db = db_connect();
    $userId = (int) $_SESSION['user_id'];

    // "Mark content complete" action
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mark_complete'])) {
        if (verify_csrf_token($_POST['csrf_token'] ?? '')) {
            portal_mark_module_complete($db, $userId, $moduleId);
            flash_set('success', 'Module ' . $moduleId . ' content marked as complete. Pass the exit quiz to unlock the next module.');
        }
        header('Location: ' . site_url("modules/module{$moduleId}/index.php"));
        exit;
    }

    $module = $modules[$moduleId];
    $completed = portal_get_completed_modules($db, $userId);
    $passed = portal_get_passed_modules($db, $userId);
    $materials = portal_get_materials_for_user($db, $userId, $moduleId);
    $contentDone = isset($completed[$moduleId]);
    $quizPassed = isset($passed[$moduleId]);

    render_head('Module ' . $moduleId . ' - ' . $module['title'], ['js/module.js']);
    ?>
    <body>
      <?php render_navigation(); ?>
      <?php render_module_navigation($moduleId, 'module'); ?>
      <div class="page-container module-page">
        <?php render_flash_messages(); ?>
        <div class="section-header">
          <div>
            <h1>Module <?php echo $moduleId; ?> &ndash; <?php echo html_escape($module['title']); ?></h1>
          </div>
          <div class="module-state-chips">
            <span class="status-chip <?php echo $contentDone ? 'chip-approved' : 'chip-pending'; ?>"><?php echo $contentDone ? 'Content completed' : 'Content in progress'; ?></span>
            <span class="status-chip <?php echo $quizPassed ? 'chip-approved' : 'chip-pending'; ?>"><?php echo $quizPassed ? 'Quiz passed' : 'Quiz not passed yet'; ?></span>
          </div>
        </div>

        <div class="module-summary">
          <p><?php echo html_escape($module['overview']); ?></p>
          <p><strong>Module goal:</strong> <?php echo html_escape($module['goal']); ?></p>
        </div>

        <div class="module-card">
          <h2>What you will cover</h2>
          <ul>
            <?php foreach ($module['topics'] as $topic): ?>
              <li><?php echo html_escape($topic); ?></li>
            <?php endforeach; ?>
          </ul>
          <h3>Learning outcomes</h3>
          <ul>
            <?php foreach ($module['learning_outcomes'] as $goal): ?>
              <li><?php echo html_escape($goal); ?></li>
            <?php endforeach; ?>
          </ul>
        </div>

        <div class="module-card">
          <h2>Module materials</h2>
          <?php if (empty($materials)): ?>
            <p>No downloadable materials have been published for this module yet. Check the <a href="<?php echo html_escape(site_url('materials.php')); ?>">Materials page</a> for general course resources.</p>
          <?php else: ?>
            <ul class="material-list">
              <?php foreach ($materials as $material): ?>
                <li class="material-item">
                  <div>
                    <strong><?php echo html_escape($material['title']); ?></strong>
                    <?php if (!empty($material['description'])): ?>
                      <p class="material-description"><?php echo html_escape($material['description']); ?></p>
                    <?php endif; ?>
                    <span class="material-meta"><?php echo html_escape($material['original_name']); ?> &middot; <?php echo format_file_size((int) $material['file_size']); ?></span>
                  </div>
                  <a class="btn btn-soft" href="<?php echo html_escape(site_url('download.php?type=material&id=' . (int) $material['id'])); ?>">Download</a>
                </li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>
        </div>

        <div class="module-actions">
          <?php if (!$contentDone): ?>
            <form method="post" class="inline-form">
              <?php echo csrf_input_field(); ?>
              <button type="submit" name="mark_complete" value="1" class="btn btn-secondary">Mark content complete</button>
            </form>
          <?php endif; ?>
          <a href="<?php echo html_escape(site_url("modules/module{$moduleId}/quiz.php")); ?>" class="btn btn-primary">Take Module <?php echo $moduleId; ?> Exit Quiz</a>
          <a href="<?php echo html_escape(site_url('index.php')); ?>" class="btn btn-soft">Back to course path</a>
        </div>
      </div>
      <?php render_page_footer(); ?>
    </body>
    </html>
    <?php
}

function render_module_quiz(int $moduleId): void
{
    $modules = get_module_metadata();
    $allQuestions = get_quiz_questions();
    if (!isset($modules[$moduleId]) || !isset($allQuestions[$moduleId])) {
        http_response_code(404);
        echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>Quiz not found</title></head><body><h1>Quiz not found</h1><p>The requested quiz does not exist.</p></body></html>';
        return;
    }

    require_module_unlocked($moduleId, 'quiz');

    $db = db_connect();
    $userId = (int) $_SESSION['user_id'];
    $module = $modules[$moduleId];
    $questions = $allQuestions[$moduleId];
    $formError = '';
    $submitted = [];

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_quiz'])) {
        if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
            $formError = 'Your session expired. Please submit your answers again.';
        } else {
            $submitted = $_POST['answers'] ?? [];
            $missing = false;
            foreach ($questions as $index => $question) {
                if (!isset($submitted[$index]) || $submitted[$index] === '') {
                    $missing = true;
                    break;
                }
            }

            if ($missing) {
                $formError = 'Please answer every question before submitting.';
            } else {
                $score = 0;
                $cleanAnswers = [];
                foreach ($questions as $index => $question) {
                    $choice = (int) $submitted[$index];
                    $cleanAnswers[$index] = $choice;
                    if ($choice === (int) $question['answer']) {
                        $score++;
                    }
                }

                $result = portal_record_quiz_attempt($db, $userId, $moduleId, $score, count($questions), $cleanAnswers);
                if ($result['passed']) {
                    $nextModule = $moduleId + 1;
                    $nextText = $nextModule <= TOTAL_MODULES
                        ? ' Module ' . $nextModule . ' is now unlocked.'
                        : ' You have completed the full learning path - congratulations!';
                    flash_set('success', sprintf('You passed with %.0f%% (%d/%d).%s', $result['percent'], $score, count($questions), $nextText));
                } else {
                    flash_set('error', sprintf('You scored %.0f%% (%d/%d). You need %d%% to pass - review the module and try again.', $result['percent'], $score, count($questions), QUIZ_PASS_MARK));
                }
                header('Location: ' . site_url("modules/module{$moduleId}/quiz.php"));
                exit;
            }
        }
    }

    $attempts = portal_get_quiz_attempts($db, $userId, $moduleId);
    $lastAttempt = $attempts[0] ?? null;
    $lastAnswers = [];
    if ($lastAttempt) {
        $stmt = $db->prepare("SELECT answers FROM quiz_attempts WHERE id = ?");
        $stmt->bind_param('i', $lastAttempt['id']);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        $decoded = $row ? json_decode($row['answers'] ?? '[]', true) : null;
        $lastAnswers = is_array($decoded) ? $decoded : [];
    }
    $passedAlready = $lastAttempt && array_filter($attempts, fn ($a) => (int) $a['passed'] === 1);

    render_head('Module ' . $moduleId . ' Exit Quiz');
    ?>
    <body>
      <?php render_navigation(); ?>
      <?php render_module_navigation($moduleId, 'quiz'); ?>
      <div class="page-container quiz-page">
        <?php render_flash_messages(); ?>
        <h1>Module <?php echo $moduleId; ?> Exit Quiz</h1>

        <?php if ($formError): ?>
          <div class="flash-message flash-error" role="alert"><?php echo html_escape($formError); ?></div>
        <?php endif; ?>

        <?php if ($lastAttempt): ?>
          <div class="info-panel">
            <h2>Your latest attempt</h2>
            <p>
              Score: <strong><?php echo (int) $lastAttempt['score']; ?>/<?php echo (int) $lastAttempt['total']; ?>
              (<?php echo number_format((float) $lastAttempt['percent'], 0); ?>%)</strong>
              &middot; <?php echo ((int) $lastAttempt['passed']) === 1 ? '<span class="status-chip chip-approved">Passed</span>' : '<span class="status-chip chip-rejected">Not passed</span>'; ?>
              &middot; <?php echo html_escape($lastAttempt['attempted_at']); ?>
            </p>
            <?php if ($passedAlready && $moduleId < TOTAL_MODULES): ?>
              <p><a class="btn btn-primary" href="<?php echo html_escape(site_url('modules/module' . ($moduleId + 1) . '/index.php')); ?>">Continue to Module <?php echo $moduleId + 1; ?> &rarr;</a></p>
            <?php endif; ?>
          </div>
        <?php endif; ?>

        <div class="exit-quiz-card">
          <p>Complete this quiz to check your understanding of <strong><?php echo html_escape($module['title']); ?></strong>.
             You need <strong><?php echo QUIZ_PASS_MARK; ?>%</strong> to pass and unlock the next module. You can retry as many times as you need.</p>
          <form method="post">
            <?php echo csrf_input_field(); ?>
            <ol class="question-list">
              <?php foreach ($questions as $index => $item): ?>
                <li class="question-item">
                  <p><?php echo ($index + 1) . '. ' . html_escape($item['question']); ?>
                  <?php if ($lastAttempt && array_key_exists($index, $lastAnswers)): ?>
                    <?php echo ((int) $lastAnswers[$index] === (int) $item['answer']) ? '<span class="answer-mark answer-correct" title="Correct on your last attempt">&#10003;</span>' : '<span class="answer-mark answer-wrong" title="Incorrect on your last attempt">&#10007;</span>'; ?>
                  <?php endif; ?>
                  </p>
                  <div class="question-options">
                    <?php foreach ($item['options'] as $optionIndex => $option): ?>
                      <label>
                        <input type="radio" name="answers[<?php echo $index; ?>]" value="<?php echo $optionIndex; ?>" required>
                        <?php echo html_escape($option); ?>
                      </label>
                    <?php endforeach; ?>
                  </div>
                </li>
              <?php endforeach; ?>
            </ol>
            <div class="module-actions">
              <button type="submit" name="submit_quiz" value="1" class="btn btn-primary">Submit answers</button>
              <a href="<?php echo html_escape(site_url("modules/module{$moduleId}/index.php")); ?>" class="btn btn-secondary">Back to module</a>
            </div>
          </form>
        </div>

        <?php if (count($attempts) > 1): ?>
          <div class="course-card">
            <h2>Attempt history</h2>
            <table class="course-table">
              <tr><th>Date</th><th>Score</th><th>Percent</th><th>Result</th></tr>
              <?php foreach ($attempts as $attempt): ?>
                <tr>
                  <td><?php echo html_escape($attempt['attempted_at']); ?></td>
                  <td><?php echo (int) $attempt['score']; ?>/<?php echo (int) $attempt['total']; ?></td>
                  <td><?php echo number_format((float) $attempt['percent'], 0); ?>%</td>
                  <td><?php echo ((int) $attempt['passed']) === 1 ? 'Passed' : 'Not passed'; ?></td>
                </tr>
              <?php endforeach; ?>
            </table>
          </div>
        <?php endif; ?>
      </div>
      <?php render_page_footer(); ?>
    </body>
    </html>
    <?php
}
