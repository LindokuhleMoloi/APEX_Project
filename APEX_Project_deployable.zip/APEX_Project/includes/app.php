<?php
// Shared application utilities for SS_Portal.
// Configuration can be overridden with environment variables so the same
// code runs on XAMPP, cPanel shared hosting, or a container without edits.

define('APP_BASE_PATH', __DIR__ . '/../');
define('APP_NAME', getenv('SS_PORTAL_APP_NAME') ?: 'SS Learner Portal');
define('DB_HOST', getenv('SS_PORTAL_DB_HOST') ?: 'localhost');
define('DB_USER', getenv('SS_PORTAL_DB_USER') ?: 'root');
define('DB_PASS', getenv('SS_PORTAL_DB_PASS') !== false ? getenv('SS_PORTAL_DB_PASS') : '');
define('DB_NAME', getenv('SS_PORTAL_DB_NAME') ?: 'ss_portal');
define('LOG_DIR', APP_BASE_PATH . 'logs');
define('CACHE_DIR', APP_BASE_PATH . 'cache');
define('ASSETS_DIR', APP_BASE_PATH . 'assets/');
define('ASSETS_URL', 'assets');
define('UPLOADS_DIR', APP_BASE_PATH . 'uploads');
define('ENABLE_IP_FILTERING', false);
define('ALLOWED_IPS', ['127.0.0.1', '::1']);
define('REQUEST_LOG_FILE', LOG_DIR . '/requests.log');
define('PERFORMANCE_LOG_FILE', LOG_DIR . '/performance.log');
define('ERROR_LOG_FILE', LOG_DIR . '/errors.log');

// Learning rules
define('QUIZ_PASS_MARK', 60); // percentage required to pass a module exit quiz
define('TOTAL_MODULES', 6);

// Upload rules
define('MAX_UPLOAD_BYTES', 15 * 1024 * 1024); // 15 MB per file
define('ALLOWED_UPLOAD_EXTENSIONS', [
    'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx',
    'txt', 'csv', 'zip', 'png', 'jpg', 'jpeg', 'gif', 'mp4', 'mp3',
]);
define('ALLOWED_AVATAR_EXTENSIONS', ['png', 'jpg', 'jpeg', 'gif']);

foreach ([LOG_DIR, CACHE_DIR, ASSETS_DIR, ASSETS_DIR . 'css',
          UPLOADS_DIR, UPLOADS_DIR . '/materials', UPLOADS_DIR . '/documents', UPLOADS_DIR . '/avatars'] as $dir) {
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
}

function app_start(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => '/',
            'httponly' => true,
            'samesite' => 'Lax',
            'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        ]);
        session_start();
    }
    enforce_ip_filtering();
    register_default_services();
    start_request_timer();
    register_shutdown_function('end_request_timer');
}

function db_connect(): mysqli
{
    static $shared = null;
    if ($shared instanceof mysqli) {
        return $shared;
    }
    mysqli_report(MYSQLI_REPORT_OFF);
    $mysqli = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($mysqli->connect_errno) {
        log_error('db_connect_failed: ' . $mysqli->connect_error);
        http_response_code(503);
        die('The portal database is not available right now. Please try again shortly or contact your training coordinator.');
    }
    $mysqli->set_charset('utf8mb4');
    $shared = $mysqli;
    return $mysqli;
}

function is_user_logged_in(): bool
{
    app_start();
    return !empty($_SESSION['user_id']);
}

function is_admin_logged_in(): bool
{
    app_start();
    return !empty($_SESSION['admin_logged_in']);
}

function require_user(): void
{
    app_start();
    if (!is_user_logged_in()) {
        header('Location: ' . site_url('login.php'));
        exit;
    }
}

function require_admin(): void
{
    app_start();
    if (!is_admin_logged_in()) {
        header('Location: ' . site_url('admin_login.php'));
        exit;
    }
}

function logout_user(): void
{
    app_start();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}

// ---------------------------------------------------------------------------
// Flash messages (one-shot notices shown after a redirect)
// ---------------------------------------------------------------------------

function flash_set(string $type, string $message): void
{
    $_SESSION['_flash'][] = ['type' => $type, 'message' => $message];
}

function flash_pull(): array
{
    $messages = $_SESSION['_flash'] ?? [];
    unset($_SESSION['_flash']);
    return $messages;
}

function render_flash_messages(): void
{
    foreach (flash_pull() as $flash) {
        $class = $flash['type'] === 'error' ? 'flash-message flash-error' : 'flash-message flash-success';
        echo '<div class="' . $class . '" role="status">' . html_escape($flash['message']) . '</div>';
    }
}

// ---------------------------------------------------------------------------
// Request logging
// ---------------------------------------------------------------------------

function start_request_timer(): void
{
    if (!isset($GLOBALS['_app_request_timer'])) {
        $GLOBALS['_app_request_timer'] = microtime(true);
    }
}

function end_request_timer(): void
{
    if (isset($GLOBALS['_app_request_timer'])) {
        $elapsed = microtime(true) - $GLOBALS['_app_request_timer'];
        log_performance(sprintf('elapsed=%.4f', $elapsed));
        log_request(sprintf('elapsed=%.4f', $elapsed));
        unset($GLOBALS['_app_request_timer']);
    }
}

function log_request(string $message = ''): void
{
    $uri = $_SERVER['REQUEST_URI'] ?? 'unknown';
    $method = $_SERVER['REQUEST_METHOD'] ?? 'CLI';
    $line = sprintf('[%s] %s %s %s', date('Y-m-d H:i:s'), $method, $uri, $message);
    @file_put_contents(REQUEST_LOG_FILE, $line . PHP_EOL, FILE_APPEND);
}

function log_performance(string $message = ''): void
{
    $uri = $_SERVER['REQUEST_URI'] ?? 'unknown';
    $method = $_SERVER['REQUEST_METHOD'] ?? 'CLI';
    $line = sprintf('[%s] %s %s %s', date('Y-m-d H:i:s'), $method, $uri, $message);
    @file_put_contents(PERFORMANCE_LOG_FILE, $line . PHP_EOL, FILE_APPEND);
}

function log_error(string $message = ''): void
{
    $uri = $_SERVER['REQUEST_URI'] ?? 'unknown';
    $method = $_SERVER['REQUEST_METHOD'] ?? 'CLI';
    $line = sprintf('[%s] %s %s %s', date('Y-m-d H:i:s'), $method, $uri, $message);
    @file_put_contents(ERROR_LOG_FILE, $line . PHP_EOL, FILE_APPEND);
}

// ---------------------------------------------------------------------------
// Cache
// ---------------------------------------------------------------------------

function cache_get(string $key, int $ttl = 60)
{
    $cacheFile = CACHE_DIR . '/' . preg_replace('/[^a-z0-9_-]/i', '_', $key) . '.json';
    if (!is_file($cacheFile)) {
        return null;
    }
    $data = json_decode(file_get_contents($cacheFile), true);
    if (!is_array($data) || empty($data['expires']) || time() > $data['expires']) {
        @unlink($cacheFile);
        return null;
    }
    return $data['value'];
}

function cache_set(string $key, $value, int $ttl = 60): void
{
    $cacheFile = CACHE_DIR . '/' . preg_replace('/[^a-z0-9_-]/i', '_', $key) . '.json';
    $data = [
        'expires' => time() + $ttl,
        'value' => $value,
    ];
    file_put_contents($cacheFile, json_encode($data));
}

function cache_forget(string $key): void
{
    $cacheFile = CACHE_DIR . '/' . preg_replace('/[^a-z0-9_-]/i', '_', $key) . '.json';
    @unlink($cacheFile);
}

// ---------------------------------------------------------------------------
// Output and CSRF helpers
// ---------------------------------------------------------------------------

function html_escape(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function generate_csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf_token(?string $token): bool
{
    return !empty($token) && !empty($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function csrf_input_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . html_escape(generate_csrf_token()) . '">';
}

// ---------------------------------------------------------------------------
// Service container
// ---------------------------------------------------------------------------

function register_service(string $name, $service, bool $override = false): void
{
    $GLOBALS['_app_services'] = $GLOBALS['_app_services'] ?? [];
    if (isset($GLOBALS['_app_services'][$name]) && !$override) {
        return;
    }
    $GLOBALS['_app_services'][$name] = $service;
}

function has_service(string $name): bool
{
    return isset($GLOBALS['_app_services']) && array_key_exists($name, $GLOBALS['_app_services']);
}

function get_service(string $name)
{
    if (!has_service($name)) {
        throw new RuntimeException("Service '{$name}' is not registered.");
    }

    $service = $GLOBALS['_app_services'][$name];
    if (is_callable($service)) {
        $service = $service();
        $GLOBALS['_app_services'][$name] = $service;
    }
    return $service;
}

function register_default_services(): void
{
    register_service('logger', function () {
        return new class {
            public function log(string $message): void
            {
                log_request($message);
            }

            public function error(string $message): void
            {
                log_error($message);
            }
        };
    });

    register_service('db', function () {
        return db_connect();
    });

    register_service('cache', function () {
        return new class {
            public function get(string $key, int $ttl = 60)
            {
                return cache_get($key, $ttl);
            }

            public function set(string $key, $value, int $ttl = 60): void
            {
                cache_set($key, $value, $ttl);
            }
        };
    });
}

// ---------------------------------------------------------------------------
// URL helpers
// ---------------------------------------------------------------------------

function site_base_url(): string
{
    $documentRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '';
    $appPath = realpath(APP_BASE_PATH) ?: '';
    $baseUrl = '';

    if ($documentRoot && $appPath && str_starts_with($appPath, $documentRoot)) {
        $relative = substr($appPath, strlen($documentRoot));
        $baseUrl = str_replace('\\', '/', $relative);
    }

    return rtrim($baseUrl ?: '', '/') ?: '';
}

function site_url(string $path): string
{
    $baseUrl = site_base_url();
    $path = '/' . ltrim($path, '/');
    return ($baseUrl ? '/' . ltrim($baseUrl, '/') : '') . $path;
}

function asset_url(string $path): string
{
    $baseUrl = site_base_url();
    $assetPath = trim(ASSETS_URL, '/') . '/' . ltrim($path, '/');
    return ($baseUrl ? '/' . ltrim($baseUrl, '/') : '') . '/' . $assetPath;
}

function render_stylesheet(string $stylesheet = 'css/style.css'): void
{
    echo '<link rel="stylesheet" href="' . html_escape(asset_url($stylesheet)) . '">';
}

function render_script(string $script): void
{
    echo '<script src="' . html_escape(asset_url($script)) . '" defer></script>';
}

// ---------------------------------------------------------------------------
// Shared layout
// ---------------------------------------------------------------------------

function render_head(string $title, array $scripts = []): void
{
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>' . html_escape($title) . ' - ' . html_escape(APP_NAME) . '</title>';
    render_stylesheet();
    foreach ($scripts as $script) {
        render_script($script);
    }
    echo '</head>';
}

function render_page_footer(): void
{
    echo '<footer class="site-footer">';
    echo '<p>&copy; ' . date('Y') . ' ' . html_escape(APP_NAME) . ' &middot; Skills development learnership portal</p>';
    echo '<p class="footer-small">Supporting SETA-accredited learnerships hosted by B-BBEE compliant South African employers. ';
    echo 'Personal information is processed in line with POPIA for training administration only.</p>';
    echo '</footer>';
}

// ---------------------------------------------------------------------------
// Security helpers
// ---------------------------------------------------------------------------

function get_client_ip(): string
{
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    }
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
    }
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

function is_ip_allowed(): bool
{
    if (!ENABLE_IP_FILTERING) {
        return true;
    }

    return in_array(get_client_ip(), ALLOWED_IPS, true);
}

function enforce_ip_filtering(): void
{
    if (!is_ip_allowed()) {
        log_request('blocked_ip=' . get_client_ip());
        http_response_code(403);
        exit('Access denied.');
    }
}

function sanitize_string(?string $value): string
{
    return trim(filter_var($value ?? '', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
}

function is_valid_sa_id_number(string $idNumber): bool
{
    return preg_match('/^\d{13}$/', $idNumber) === 1;
}

// ---------------------------------------------------------------------------
// Navigation
// ---------------------------------------------------------------------------

function render_navigation(): void
{
    $links = [
        'index.php' => 'Home',
        'courses.php' => 'Courses',
        'materials.php' => 'Materials',
        'quizzes.php' => 'Quizzes',
        'grades.php' => 'Grades',
        'documents.php' => 'My Documents',
        'profile.php' => 'Profile',
    ];

    $current = basename($_SERVER['SCRIPT_NAME'] ?? '');

    echo '<header class="topbar">';
    echo '<div class="brand"><a href="' . html_escape(site_url('index.php')) . '">' . html_escape(APP_NAME) . '</a></div>';
    echo '<button type="button" class="nav-toggle" aria-label="Toggle menu" aria-expanded="false">&#9776;</button>';
    echo '<nav class="nav-links">';

    foreach ($links as $href => $label) {
        $active = $current === $href ? ' class="active"' : '';
        echo '<a href="' . html_escape(site_url($href)) . '"' . $active . '>' . html_escape($label) . '</a>';
    }

    $loggedIn = !empty($_SESSION['user_id']) || !empty($_SESSION['admin_logged_in']);
    if ($loggedIn) {
        echo '<a href="' . html_escape(site_url('logout.php')) . '" class="nav-logout">Logout</a>';
    } else {
        echo '<a href="' . html_escape(site_url('login.php')) . '" class="nav-logout">Login</a>';
    }

    echo '</nav>';
    echo '</header>';
}

function render_admin_navigation(): void
{
    $links = [
        'dashboard.php' => 'Dashboard',
        'admin_learners.php' => 'Learners',
        'admin_materials.php' => 'Materials',
        'admin_documents.php' => 'Documents',
        'admin_results.php' => 'Results',
        'admin_announcements.php' => 'Announcements',
    ];

    $current = basename($_SERVER['SCRIPT_NAME'] ?? '');

    echo '<header class="topbar topbar-admin">';
    echo '<div class="brand"><a href="' . html_escape(site_url('dashboard.php')) . '">' . html_escape(APP_NAME) . ' &middot; Admin</a></div>';
    echo '<button type="button" class="nav-toggle" aria-label="Toggle menu" aria-expanded="false">&#9776;</button>';
    echo '<nav class="nav-links">';
    foreach ($links as $href => $label) {
        $active = $current === $href ? ' class="active"' : '';
        echo '<a href="' . html_escape(site_url($href)) . '"' . $active . '>' . html_escape($label) . '</a>';
    }
    echo '<a href="' . html_escape(site_url('logout.php')) . '" class="nav-logout">Logout</a>';
    echo '</nav>';
    echo '</header>';
}

// ---------------------------------------------------------------------------
// File upload / download helpers
// ---------------------------------------------------------------------------

function format_file_size(int $bytes): string
{
    if ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 1) . ' MB';
    }
    if ($bytes >= 1024) {
        return number_format($bytes / 1024, 1) . ' KB';
    }
    return $bytes . ' B';
}

/**
 * Validates and stores an uploaded file inside uploads/<subdir>/.
 *
 * Returns ['ok' => true, 'path' => relative path, 'original_name', 'size', 'mime']
 * or ['ok' => false, 'error' => message].
 */
function handle_file_upload(array $file, string $subdir, ?array $allowedExtensions = null, int $maxBytes = MAX_UPLOAD_BYTES): array
{
    $allowedExtensions = $allowedExtensions ?: ALLOWED_UPLOAD_EXTENSIONS;

    if (!isset($file['error']) || is_array($file['error'])) {
        return ['ok' => false, 'error' => 'Invalid upload request.'];
    }
    if ($file['error'] === UPLOAD_ERR_NO_FILE) {
        return ['ok' => false, 'error' => 'Please choose a file to upload.'];
    }
    if ($file['error'] === UPLOAD_ERR_INI_SIZE || $file['error'] === UPLOAD_ERR_FORM_SIZE) {
        return ['ok' => false, 'error' => 'The file is too large. Maximum size is ' . format_file_size($maxBytes) . '.'];
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'error' => 'Upload failed. Please try again.'];
    }
    if ($file['size'] <= 0 || $file['size'] > $maxBytes) {
        return ['ok' => false, 'error' => 'The file is too large. Maximum size is ' . format_file_size($maxBytes) . '.'];
    }

    $originalName = $file['name'];
    $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
    if (!in_array($extension, $allowedExtensions, true)) {
        return ['ok' => false, 'error' => 'File type ".' . $extension . '" is not allowed. Allowed types: ' . implode(', ', $allowedExtensions) . '.'];
    }

    $mime = 'application/octet-stream';
    if (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo) {
            $detected = finfo_file($finfo, $file['tmp_name']);
            if ($detected) {
                $mime = $detected;
            }
            finfo_close($finfo);
        }
    }
    if (in_array($mime, ['application/x-php', 'text/x-php', 'application/x-httpd-php'], true)) {
        return ['ok' => false, 'error' => 'This file type is not allowed.'];
    }

    $subdir = trim($subdir, '/');
    $targetDir = UPLOADS_DIR . '/' . $subdir;
    if (!is_dir($targetDir) && !@mkdir($targetDir, 0755, true)) {
        return ['ok' => false, 'error' => 'Upload folder is not available.'];
    }

    $storedName = date('Ymd_His') . '_' . bin2hex(random_bytes(8)) . '.' . $extension;
    $targetPath = $targetDir . '/' . $storedName;

    $moved = is_uploaded_file($file['tmp_name'])
        ? move_uploaded_file($file['tmp_name'], $targetPath)
        : @rename($file['tmp_name'], $targetPath); // supports CLI smoke tests

    if (!$moved) {
        log_error('upload_move_failed: ' . $targetPath);
        return ['ok' => false, 'error' => 'Could not save the uploaded file.'];
    }
    @chmod($targetPath, 0644);

    return [
        'ok' => true,
        'path' => $subdir . '/' . $storedName,
        'original_name' => $originalName,
        'size' => (int) $file['size'],
        'mime' => $mime,
    ];
}

/**
 * Streams a stored upload to the browser. $relativePath must be a path
 * previously produced by handle_file_upload() (relative to uploads/).
 */
function stream_stored_file(string $relativePath, string $downloadName, string $mime = 'application/octet-stream', bool $inline = false): void
{
    $fullPath = realpath(UPLOADS_DIR . '/' . ltrim($relativePath, '/'));
    $uploadsRoot = realpath(UPLOADS_DIR);

    if (!$fullPath || !$uploadsRoot || !str_starts_with($fullPath, $uploadsRoot . DIRECTORY_SEPARATOR) || !is_file($fullPath)) {
        http_response_code(404);
        exit('File not found.');
    }

    $safeName = preg_replace('/[^\w\s.\-()]/u', '_', $downloadName) ?: 'download';
    $disposition = $inline ? 'inline' : 'attachment';

    if (ob_get_level()) {
        ob_end_clean();
    }
    header('Content-Type: ' . $mime);
    header('Content-Length: ' . filesize($fullPath));
    header('Content-Disposition: ' . $disposition . '; filename="' . $safeName . '"');
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: private, max-age=0, must-revalidate');
    readfile($fullPath);
    exit;
}
