<?php
// Domain layer for SS_Portal: enrollments, module progress, quiz attempts,
// learning materials, learner documents, and announcements.

require_once __DIR__ . '/app.php';

// ---------------------------------------------------------------------------
// Courses and enrollment
// ---------------------------------------------------------------------------

function portal_get_courses(mysqli $db): array
{
    $result = $db->query(
        "SELECT id, name, code, nqf_level, saqa_id, credits, duration_months, seta, description
         FROM subjects ORDER BY nqf_level, name");
    return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
}

function portal_get_user_registrations(mysqli $db, int $userId): array
{
    $stmt = $db->prepare(
        "SELECT r.id, r.subject_id, r.status, r.registration_date,
                s.name, s.code, s.nqf_level, s.saqa_id, s.credits, s.duration_months, s.seta, s.description
         FROM registrations r
         JOIN subjects s ON s.id = r.subject_id
         WHERE r.user_id = ?
         ORDER BY r.registration_date DESC");
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $rows;
}

function portal_get_active_registration(mysqli $db, int $userId): ?array
{
    foreach (portal_get_user_registrations($db, $userId) as $registration) {
        if ($registration['status'] === 'Approved') {
            return $registration;
        }
    }
    $all = portal_get_user_registrations($db, $userId);
    return $all[0] ?? null;
}

function portal_request_enrollment(mysqli $db, int $userId, int $subjectId, ?string $email = null): array
{
    $stmt = $db->prepare("SELECT id, status FROM registrations WHERE user_id = ? AND subject_id = ? LIMIT 1");
    $stmt->bind_param('ii', $userId, $subjectId);
    $stmt->execute();
    $existing = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($existing) {
        return ['ok' => false, 'error' => 'You have already requested this course (status: ' . $existing['status'] . ').'];
    }

    $stmt = $db->prepare("INSERT INTO registrations (user_id, subject_id, email) VALUES (?, ?, ?)");
    $stmt->bind_param('iis', $userId, $subjectId, $email);
    $ok = $stmt->execute();
    $stmt->close();
    cache_forget('subjects_for_user_' . $userId);

    return $ok
        ? ['ok' => true]
        : ['ok' => false, 'error' => 'Could not submit the enrollment request. Please try again.'];
}

function portal_user_has_approved_course(mysqli $db, int $userId): bool
{
    $stmt = $db->prepare("SELECT COUNT(*) AS c FROM registrations WHERE user_id = ? AND status = 'Approved'");
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $count = (int) $stmt->get_result()->fetch_assoc()['c'];
    $stmt->close();
    return $count > 0;
}

// ---------------------------------------------------------------------------
// Module progress and drip unlocking
// ---------------------------------------------------------------------------

function portal_get_completed_modules(mysqli $db, int $userId): array
{
    $stmt = $db->prepare("SELECT module_number, completed_at FROM module_progress WHERE user_id = ?");
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    $completed = [];
    foreach ($rows as $row) {
        $completed[(int) $row['module_number']] = $row['completed_at'];
    }
    return $completed;
}

function portal_get_passed_modules(mysqli $db, int $userId): array
{
    $stmt = $db->prepare(
        "SELECT module_number, MAX(percent) AS best_percent
         FROM quiz_attempts WHERE user_id = ? AND passed = 1
         GROUP BY module_number");
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    $passed = [];
    foreach ($rows as $row) {
        $passed[(int) $row['module_number']] = (float) $row['best_percent'];
    }
    return $passed;
}

function portal_mark_module_complete(mysqli $db, int $userId, int $moduleNumber): void
{
    $stmt = $db->prepare(
        "INSERT IGNORE INTO module_progress (user_id, module_number) VALUES (?, ?)");
    $stmt->bind_param('ii', $userId, $moduleNumber);
    $stmt->execute();
    $stmt->close();
}

/**
 * Module 1 is always open. Module N opens once the module N-1 exit quiz
 * has been passed (the course "drip" rule).
 */
function portal_is_module_unlocked(mysqli $db, int $userId, int $moduleNumber): bool
{
    if ($moduleNumber <= 1) {
        return true;
    }
    if ($moduleNumber > TOTAL_MODULES) {
        return false;
    }
    $passed = portal_get_passed_modules($db, $userId);
    return isset($passed[$moduleNumber - 1]);
}

function portal_overall_progress_percent(mysqli $db, int $userId): int
{
    $passed = portal_get_passed_modules($db, $userId);
    return (int) round(count($passed) / TOTAL_MODULES * 100);
}

// ---------------------------------------------------------------------------
// Quiz attempts
// ---------------------------------------------------------------------------

function portal_record_quiz_attempt(mysqli $db, int $userId, int $moduleNumber, int $score, int $total, array $answers): array
{
    $percent = $total > 0 ? round($score / $total * 100, 2) : 0.0;
    $passed = $percent >= QUIZ_PASS_MARK ? 1 : 0;
    $answersJson = json_encode($answers);

    $stmt = $db->prepare(
        "INSERT INTO quiz_attempts (user_id, module_number, score, total, percent, passed, answers)
         VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param('iiiidis', $userId, $moduleNumber, $score, $total, $percent, $passed, $answersJson);
    $stmt->execute();
    $stmt->close();

    if ($passed) {
        portal_mark_module_complete($db, $userId, $moduleNumber);
    }

    return ['percent' => $percent, 'passed' => (bool) $passed];
}

function portal_get_quiz_attempts(mysqli $db, int $userId, ?int $moduleNumber = null): array
{
    if ($moduleNumber !== null) {
        $stmt = $db->prepare(
            "SELECT id, module_number, score, total, percent, passed, attempted_at
             FROM quiz_attempts WHERE user_id = ? AND module_number = ?
             ORDER BY attempted_at DESC");
        $stmt->bind_param('ii', $userId, $moduleNumber);
    } else {
        $stmt = $db->prepare(
            "SELECT id, module_number, score, total, percent, passed, attempted_at
             FROM quiz_attempts WHERE user_id = ?
             ORDER BY attempted_at DESC");
        $stmt->bind_param('i', $userId);
    }
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $rows;
}

function portal_get_best_attempts(mysqli $db, int $userId): array
{
    $stmt = $db->prepare(
        "SELECT module_number,
                MAX(percent) AS best_percent,
                MAX(passed) AS passed,
                COUNT(*) AS attempts
         FROM quiz_attempts WHERE user_id = ?
         GROUP BY module_number");
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    $best = [];
    foreach ($rows as $row) {
        $best[(int) $row['module_number']] = $row;
    }
    return $best;
}

// ---------------------------------------------------------------------------
// Learning materials (admin uploads, learner downloads)
// ---------------------------------------------------------------------------

function portal_add_material(mysqli $db, ?int $subjectId, ?int $moduleNumber, string $title, string $description, array $stored, string $uploadedBy): bool
{
    $stmt = $db->prepare(
        "INSERT INTO learning_materials (subject_id, module_number, title, description, file_path, original_name, file_size, mime_type, uploaded_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param(
        'iissssiss',
        $subjectId,
        $moduleNumber,
        $title,
        $description,
        $stored['path'],
        $stored['original_name'],
        $stored['size'],
        $stored['mime'],
        $uploadedBy
    );
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

function portal_get_materials(mysqli $db, ?int $subjectIdFilter = null): array
{
    $sql = "SELECT m.id, m.subject_id, m.module_number, m.title, m.description, m.file_path,
                   m.original_name, m.file_size, m.mime_type, m.uploaded_by, m.upload_date,
                   s.name AS subject_name
            FROM learning_materials m
            LEFT JOIN subjects s ON s.id = m.subject_id";
    if ($subjectIdFilter !== null) {
        $sql .= " WHERE m.subject_id IS NULL OR m.subject_id = ?";
    }
    $sql .= " ORDER BY COALESCE(m.module_number, 0), m.upload_date DESC";

    $stmt = $db->prepare($sql);
    if ($subjectIdFilter !== null) {
        $stmt->bind_param('i', $subjectIdFilter);
    }
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $rows;
}

/**
 * Materials visible to a learner: general materials (subject_id NULL) plus
 * materials for any course the learner has an approved registration on.
 */
function portal_get_materials_for_user(mysqli $db, int $userId, ?int $moduleNumber = null): array
{
    $approvedSubjectIds = [];
    foreach (portal_get_user_registrations($db, $userId) as $registration) {
        if ($registration['status'] === 'Approved') {
            $approvedSubjectIds[] = (int) $registration['subject_id'];
        }
    }

    $materials = portal_get_materials($db);
    return array_values(array_filter($materials, function ($material) use ($approvedSubjectIds, $moduleNumber) {
        $subjectOk = $material['subject_id'] === null || in_array((int) $material['subject_id'], $approvedSubjectIds, true);
        if (!$subjectOk) {
            return false;
        }
        if ($moduleNumber !== null) {
            return (int) ($material['module_number'] ?? 0) === $moduleNumber;
        }
        return true;
    }));
}

function portal_get_material(mysqli $db, int $materialId): ?array
{
    $stmt = $db->prepare(
        "SELECT id, subject_id, module_number, title, file_path, original_name, file_size, mime_type
         FROM learning_materials WHERE id = ? LIMIT 1");
    $stmt->bind_param('i', $materialId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $row ?: null;
}

function portal_delete_material(mysqli $db, int $materialId): bool
{
    $material = portal_get_material($db, $materialId);
    if (!$material) {
        return false;
    }
    $stmt = $db->prepare("DELETE FROM learning_materials WHERE id = ?");
    $stmt->bind_param('i', $materialId);
    $ok = $stmt->execute();
    $stmt->close();
    if ($ok && !empty($material['file_path'])) {
        @unlink(UPLOADS_DIR . '/' . $material['file_path']);
    }
    return $ok;
}

// ---------------------------------------------------------------------------
// Learner documents (uploads for ID copies, CVs, assignments, ...)
// ---------------------------------------------------------------------------

function portal_document_types(): array
{
    return [
        'Certified ID Copy',
        'CV / Resume',
        'Proof of Residence',
        'Highest Qualification Certificate',
        'Bank Confirmation Letter',
        'Assignment Submission',
        'Portfolio of Evidence',
        'Other',
    ];
}

function portal_add_document(mysqli $db, int $userId, string $docType, string $documentName, array $stored): bool
{
    $stmt = $db->prepare(
        "INSERT INTO documents (user_id, doc_type, document_name, file_path, original_name, file_size, mime_type)
         VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param(
        'issssis',
        $userId,
        $docType,
        $documentName,
        $stored['path'],
        $stored['original_name'],
        $stored['size'],
        $stored['mime']
    );
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

function portal_get_user_documents(mysqli $db, int $userId): array
{
    $stmt = $db->prepare(
        "SELECT id, doc_type, document_name, file_path, original_name, file_size, mime_type,
                status, review_note, upload_date, reviewed_at
         FROM documents WHERE user_id = ? ORDER BY upload_date DESC");
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $rows;
}

function portal_get_document(mysqli $db, int $documentId): ?array
{
    $stmt = $db->prepare(
        "SELECT d.id, d.user_id, d.doc_type, d.document_name, d.file_path, d.original_name,
                d.file_size, d.mime_type, d.status, d.review_note, d.upload_date,
                u.username
         FROM documents d
         LEFT JOIN users u ON u.id = d.user_id
         WHERE d.id = ? LIMIT 1");
    $stmt->bind_param('i', $documentId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $row ?: null;
}

function portal_delete_document(mysqli $db, int $documentId, int $userId): bool
{
    $document = portal_get_document($db, $documentId);
    if (!$document || (int) $document['user_id'] !== $userId || $document['status'] !== 'Pending') {
        return false;
    }
    $stmt = $db->prepare("DELETE FROM documents WHERE id = ? AND user_id = ?");
    $stmt->bind_param('ii', $documentId, $userId);
    $ok = $stmt->execute();
    $stmt->close();
    if ($ok && !empty($document['file_path'])) {
        @unlink(UPLOADS_DIR . '/' . $document['file_path']);
    }
    return $ok;
}

function portal_get_all_documents(mysqli $db, ?string $statusFilter = null): array
{
    $sql = "SELECT d.id, d.user_id, d.doc_type, d.document_name, d.file_path, d.original_name,
                   d.file_size, d.status, d.review_note, d.upload_date, d.reviewed_at,
                   u.username, u.full_name, u.email
            FROM documents d
            JOIN users u ON u.id = d.user_id";
    if ($statusFilter !== null) {
        $sql .= " WHERE d.status = ?";
    }
    $sql .= " ORDER BY d.upload_date DESC";

    $stmt = $db->prepare($sql);
    if ($statusFilter !== null) {
        $stmt->bind_param('s', $statusFilter);
    }
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $rows;
}

function portal_review_document(mysqli $db, int $documentId, string $status, string $note): bool
{
    if (!in_array($status, ['Approved', 'Rejected'], true)) {
        return false;
    }
    $stmt = $db->prepare(
        "UPDATE documents SET status = ?, review_note = ?, reviewed_at = NOW() WHERE id = ?");
    $stmt->bind_param('ssi', $status, $note, $documentId);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

// ---------------------------------------------------------------------------
// Announcements
// ---------------------------------------------------------------------------

function portal_get_announcements(mysqli $db, int $limit = 10): array
{
    $stmt = $db->prepare(
        "SELECT id, title, body, created_by, created_at
         FROM announcements ORDER BY created_at DESC, id DESC LIMIT ?");
    $stmt->bind_param('i', $limit);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $rows;
}

function portal_add_announcement(mysqli $db, string $title, string $body, string $createdBy): bool
{
    $stmt = $db->prepare("INSERT INTO announcements (title, body, created_by) VALUES (?, ?, ?)");
    $stmt->bind_param('sss', $title, $body, $createdBy);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

function portal_delete_announcement(mysqli $db, int $announcementId): bool
{
    $stmt = $db->prepare("DELETE FROM announcements WHERE id = ?");
    $stmt->bind_param('i', $announcementId);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

// ---------------------------------------------------------------------------
// Admin: learners and statistics
// ---------------------------------------------------------------------------

function portal_get_learners(mysqli $db, string $search = ''): array
{
    $sql = "SELECT u.id, u.username, u.full_name, u.email, u.phone, u.created_at,
                   s.name AS course_name, r.status AS registration_status
            FROM users u
            LEFT JOIN registrations r ON r.user_id = u.id
            LEFT JOIN subjects s ON s.id = r.subject_id
            WHERE u.is_admin = 0";
    if ($search !== '') {
        $sql .= " AND (u.username LIKE CONCAT('%', ?, '%')
                   OR u.full_name LIKE CONCAT('%', ?, '%')
                   OR u.email LIKE CONCAT('%', ?, '%'))";
    }
    $sql .= " ORDER BY u.created_at DESC, u.id DESC";

    $stmt = $db->prepare($sql);
    if ($search !== '') {
        $stmt->bind_param('sss', $search, $search, $search);
    }
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $rows;
}

function portal_get_learner(mysqli $db, int $userId): ?array
{
    $stmt = $db->prepare(
        "SELECT id, username, full_name, email, phone, id_number, created_at
         FROM users WHERE id = ? AND is_admin = 0 LIMIT 1");
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $row ?: null;
}

function portal_admin_stats(mysqli $db): array
{
    $stats = [
        'learners' => 0,
        'pending_registrations' => 0,
        'approved_registrations' => 0,
        'pending_documents' => 0,
        'materials' => 0,
        'quiz_attempts' => 0,
        'pass_rate' => 0,
        'announcements' => 0,
    ];

    $queries = [
        'learners' => "SELECT COUNT(*) AS c FROM users WHERE is_admin = 0",
        'pending_registrations' => "SELECT COUNT(*) AS c FROM registrations WHERE status = 'Pending'",
        'approved_registrations' => "SELECT COUNT(*) AS c FROM registrations WHERE status = 'Approved'",
        'pending_documents' => "SELECT COUNT(*) AS c FROM documents WHERE status = 'Pending'",
        'materials' => "SELECT COUNT(*) AS c FROM learning_materials",
        'quiz_attempts' => "SELECT COUNT(*) AS c FROM quiz_attempts",
        'announcements' => "SELECT COUNT(*) AS c FROM announcements",
    ];

    foreach ($queries as $key => $sql) {
        $result = $db->query($sql);
        if ($result) {
            $stats[$key] = (int) $result->fetch_assoc()['c'];
        }
    }

    $result = $db->query("SELECT AVG(passed) * 100 AS rate FROM quiz_attempts");
    if ($result) {
        $row = $result->fetch_assoc();
        $stats['pass_rate'] = $row['rate'] !== null ? (int) round((float) $row['rate']) : 0;
    }

    return $stats;
}

function portal_get_all_quiz_attempts(mysqli $db, ?int $moduleFilter = null): array
{
    $sql = "SELECT q.id, q.user_id, q.module_number, q.score, q.total, q.percent, q.passed, q.attempted_at,
                   u.username, u.full_name
            FROM quiz_attempts q
            JOIN users u ON u.id = q.user_id";
    if ($moduleFilter !== null) {
        $sql .= " WHERE q.module_number = ?";
    }
    $sql .= " ORDER BY q.attempted_at DESC LIMIT 500";

    $stmt = $db->prepare($sql);
    if ($moduleFilter !== null) {
        $stmt->bind_param('i', $moduleFilter);
    }
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $rows;
}
