<?php
require_once __DIR__ . '/includes/app.php';
app_start();
require_user();

$requestedModule = isset($_GET['module']) ? (int) $_GET['module'] : 0;
$contentType = isset($_GET['content']) ? $_GET['content'] : 'module';
$moduleNumber = $requestedModule > 0 ? $requestedModule : null;
$previousModule = $moduleNumber && $moduleNumber > 1 ? $moduleNumber - 1 : 1;
$pageTitle = $contentType === 'quiz' ? 'Quiz Locked' : 'Module Locked';
$message = $moduleNumber
    ? sprintf('Module %d is still locked. Pass the Module %d exit quiz first to unlock this content.', $moduleNumber, $previousModule)
    : 'This content is currently locked. Finish the current module to continue.';
?>
<?php render_head($pageTitle); ?>
<body>
  <?php render_navigation(); ?>
  <div class="page-container locked-page">
    <section class="locked-hero-card">
      <div class="locked-icon">&#128274;</div>
      <div>
        <h1><?php echo html_escape($pageTitle); ?></h1>
        <p><?php echo html_escape($message); ?></p>
      </div>
    </section>

    <section class="locked-info-card">
      <h2>Keep your learning flow</h2>
      <p>Complete the currently unlocked module first. The course follows a step-by-step drip path, and this helps you
         master the material before moving on. You need <?php echo QUIZ_PASS_MARK; ?>% on each exit quiz to move forward -
         and you can retry as many times as you need.</p>
      <div class="locked-actions">
        <a href="<?php echo html_escape(site_url('index.php')); ?>" class="btn btn-primary">Return to course path</a>
        <a href="<?php echo html_escape(site_url("modules/module{$previousModule}/index.php")); ?>" class="btn btn-secondary">Continue Module <?php echo $previousModule; ?></a>
      </div>
    </section>
  </div>
  <?php render_page_footer(); ?>
</body>
</html>
