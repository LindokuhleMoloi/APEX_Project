<?php
// Admin: quiz results across all learners, with per-module statistics and
// CSV export for SETA / programme reporting.

require_once __DIR__ . '/includes/app.php';
require_once __DIR__ . '/includes/portal.php';
require_once __DIR__ . '/includes/module_template.php';
app_start();
require_admin();

$db = db_connect();
$moduleMeta = get_module_metadata();

$moduleFilter = (int) ($_GET['module'] ?? 0) ?: null;
$attempts = portal_get_all_quiz_attempts($db, $moduleFilter);

// CSV export of the (filtered) results
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="quiz_results_' . date('Ymd_His') . '.csv"');
    $output = fopen('php://output', 'w');
    fputcsv($output, ['Date', 'Learner', 'Username', 'Module', 'Score', 'Total', 'Percent', 'Result']);
    foreach ($attempts as $attempt) {
        fputcsv($output, [
            $attempt['attempted_at'],
            $attempt['full_name'] ?: $attempt['username'],
            $attempt['username'],
            'Module ' . $attempt['module_number'],
            $attempt['score'],
            $attempt['total'],
            number_format((float) $attempt['percent'], 0),
            ((int) $attempt['passed']) === 1 ? 'Passed' : 'Not passed',
        ]);
    }
    fclose($output);
    exit;
}

// Per-module aggregate statistics
$moduleStats = [];
$result = $db->query(
    "SELECT module_number,
            COUNT(*) AS attempts,
            COUNT(DISTINCT user_id) AS learners,
            AVG(percent) AS avg_percent,
            AVG(passed) * 100 AS pass_rate
     FROM quiz_attempts
     GROUP BY module_number
     ORDER BY module_number");
while ($result && ($row = $result->fetch_assoc())) {
    $moduleStats[(int) $row['module_number']] = $row;
}
?>
<?php render_head('Quiz Results'); ?>
<body class="admin-body">
  <?php render_admin_navigation(); ?>
  <div class="page-container">
    <?php render_flash_messages(); ?>
    <div class="section-header">
      <div>
        <h1>Quiz Results</h1>
        <p>Module quiz performance across the programme.</p>
      </div>
      <a href="<?php echo html_escape(site_url('admin_results.php?export=csv' . ($moduleFilter ? '&module=' . $moduleFilter : ''))); ?>" class="btn btn-secondary">&#11015;&#65039; Export CSV</a>
    </div>

    <div class="course-card">
      <h2>Per-module overview</h2>
      <table class="course-table">
        <tr><th>Module</th><th>Learners</th><th>Attempts</th><th>Average %</th><th>Pass rate</th></tr>
        <?php foreach ($moduleMeta as $id => $module): ?>
          <?php $stats = $moduleStats[$id] ?? null; ?>
          <tr>
            <td>Module <?php echo $id; ?>: <?php echo html_escape($module['title']); ?></td>
            <td><?php echo $stats ? (int) $stats['learners'] : 0; ?></td>
            <td><?php echo $stats ? (int) $stats['attempts'] : 0; ?></td>
            <td><?php echo $stats ? number_format((float) $stats['avg_percent'], 1) . '%' : '-'; ?></td>
            <td><?php echo $stats ? number_format((float) $stats['pass_rate'], 0) . '%' : '-'; ?></td>
          </tr>
        <?php endforeach; ?>
      </table>
    </div>

    <div class="course-card">
      <div class="section-header">
        <h2>Attempt log<?php echo $moduleFilter ? ' - Module ' . $moduleFilter : ''; ?></h2>
        <div class="filter-tabs">
          <a href="<?php echo html_escape(site_url('admin_results.php')); ?>" class="filter-tab<?php echo $moduleFilter === null ? ' active' : ''; ?>">All</a>
          <?php foreach (array_keys($moduleMeta) as $id): ?>
            <a href="<?php echo html_escape(site_url('admin_results.php?module=' . $id)); ?>" class="filter-tab<?php echo $moduleFilter === $id ? ' active' : ''; ?>">M<?php echo $id; ?></a>
          <?php endforeach; ?>
        </div>
      </div>
      <?php if (empty($attempts)): ?>
        <p>No quiz attempts recorded<?php echo $moduleFilter ? ' for this module' : ''; ?> yet.</p>
      <?php else: ?>
        <table class="course-table">
          <tr><th>Date</th><th>Learner</th><th>Module</th><th>Score</th><th>Percent</th><th>Result</th></tr>
          <?php foreach ($attempts as $attempt): ?>
            <tr>
              <td><?php echo html_escape($attempt['attempted_at']); ?></td>
              <td><?php echo html_escape($attempt['full_name'] ?: $attempt['username']); ?></td>
              <td>Module <?php echo (int) $attempt['module_number']; ?></td>
              <td><?php echo (int) $attempt['score']; ?>/<?php echo (int) $attempt['total']; ?></td>
              <td><?php echo number_format((float) $attempt['percent'], 0); ?>%</td>
              <td><?php echo ((int) $attempt['passed']) === 1 ? '<span class="status-chip chip-approved">Passed</span>' : '<span class="status-chip chip-rejected">Not passed</span>'; ?></td>
            </tr>
          <?php endforeach; ?>
        </table>
      <?php endif; ?>
    </div>
  </div>
  <?php render_page_footer(); ?>
</body>
</html>
