<?php
require_once __DIR__ . '/includes/app.php';
app_start();

if (is_user_logged_in()) {
    header('Location: ' . site_url('index.php'));
    exit;
}

$mysqli = db_connect();

// Fetch qualifications for the dropdown
$subjects = [];
$result = $mysqli->query("SELECT id, name, nqf_level FROM subjects ORDER BY nqf_level, name");
while ($result && ($row = $result->fetch_assoc())) {
    $subjects[] = $row;
}

$message = '';
$messageType = 'error';
$old = ['username' => '', 'full_name' => '', 'email' => '', 'phone' => '', 'id_number' => '', 'subject_id' => 0];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $message = 'Your session expired. Please try again.';
    } else {
        $old['username'] = $username = sanitize_string($_POST['username'] ?? '');
        $old['full_name'] = $full_name = sanitize_string($_POST['full_name'] ?? '');
        $old['email'] = $email = sanitize_string($_POST['email'] ?? '');
        $old['phone'] = $phone = sanitize_string($_POST['phone'] ?? '');
        $old['id_number'] = $id_number = sanitize_string($_POST['id_number'] ?? '');
        $old['subject_id'] = $subject_id = intval($_POST['subject_id'] ?? 0);
        $password = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        $popia_consent = !empty($_POST['popia_consent']) ? 1 : 0;

        if (!$username || !$full_name || !$password || !$email || !$subject_id) {
            $message = 'Please fill in all required fields.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $message = 'Please enter a valid email address.';
        } elseif (strlen($password) < 8) {
            $message = 'Your password must be at least 8 characters long.';
        } elseif ($password !== $confirm_password) {
            $message = 'The two passwords do not match.';
        } elseif ($id_number !== '' && !is_valid_sa_id_number($id_number)) {
            $message = 'A South African ID number must be exactly 13 digits.';
        } elseif (!$popia_consent) {
            $message = 'Please accept the POPIA consent so we can process your enrollment.';
        } else {
            $stmt = $mysqli->prepare("SELECT id FROM users WHERE username = ?");
            $stmt->bind_param('s', $username);
            $stmt->execute();
            $stmt->store_result();
            $usernameTaken = $stmt->num_rows > 0;
            $stmt->close();

            if ($usernameTaken) {
                $message = 'That username is already taken. Please choose another one.';
            } else {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $mysqli->prepare(
                    "INSERT INTO users (username, password, email, full_name, phone, id_number, popia_consent)
                     VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param('ssssssi', $username, $hashed_password, $email, $full_name, $phone, $id_number, $popia_consent);

                if ($stmt->execute()) {
                    $user_id = $stmt->insert_id;
                    $stmt2 = $mysqli->prepare("INSERT INTO registrations (user_id, subject_id, email) VALUES (?, ?, ?)");
                    $stmt2->bind_param('iis', $user_id, $subject_id, $email);
                    $stmt2->execute();
                    $stmt2->close();

                    flash_set('success', 'Registration successful! You can log in now. Your course enrollment will be confirmed by the training provider.');
                    header('Location: ' . site_url('login.php'));
                    exit;
                }

                $message = 'Error registering your account. Please try again.';
                $stmt->close();
            }
        }
    }
}
?>
<?php render_head('Register'); ?>
<body class="auth-body">
  <div class="auth-wrapper">
    <div class="auth-card auth-card-wide">
      <div class="auth-brand">
        <div class="auth-logo">SS</div>
        <h1>Learner Registration</h1>
        <p>Create your account to join a SETA-accredited learnership programme.</p>
      </div>

      <?php if ($message): ?>
        <div class="flash-message flash-<?php echo $messageType; ?>" role="alert"><?php echo html_escape($message); ?></div>
      <?php endif; ?>

      <form method="post" action="" class="auth-form">
        <?php echo csrf_input_field(); ?>
        <div class="form-grid">
          <div class="form-group">
            <label for="full_name">Full name <span class="required">*</span></label>
            <input type="text" id="full_name" name="full_name" value="<?php echo html_escape($old['full_name']); ?>" required>
          </div>
          <div class="form-group">
            <label for="username">Username <span class="required">*</span></label>
            <input type="text" id="username" name="username" value="<?php echo html_escape($old['username']); ?>" required>
          </div>
        </div>

        <div class="form-grid">
          <div class="form-group">
            <label for="email">Email <span class="required">*</span></label>
            <input type="email" id="email" name="email" value="<?php echo html_escape($old['email']); ?>" required>
          </div>
          <div class="form-group">
            <label for="phone">Cellphone number</label>
            <input type="tel" id="phone" name="phone" value="<?php echo html_escape($old['phone']); ?>" placeholder="e.g. 072 123 4567">
          </div>
        </div>

        <div class="form-grid">
          <div class="form-group">
            <label for="id_number">SA ID number <span class="hint">(13 digits, optional now - needed for SETA registration)</span></label>
            <input type="text" id="id_number" name="id_number" value="<?php echo html_escape($old['id_number']); ?>" inputmode="numeric" maxlength="13" pattern="\d{13}">
          </div>
          <div class="form-group">
            <label for="subject_id">Qualification <span class="required">*</span></label>
            <select id="subject_id" name="subject_id" required>
              <option value="">Select a qualification</option>
              <?php foreach ($subjects as $subject): ?>
                <option value="<?php echo (int) $subject['id']; ?>"<?php echo $old['subject_id'] === (int) $subject['id'] ? ' selected' : ''; ?>>
                  <?php echo html_escape($subject['name']); ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>

        <div class="form-grid">
          <div class="form-group">
            <label for="password">Password <span class="required">*</span> <span class="hint">(minimum 8 characters)</span></label>
            <input type="password" id="password" name="password" minlength="8" autocomplete="new-password" required>
          </div>
          <div class="form-group">
            <label for="confirm_password">Confirm password <span class="required">*</span></label>
            <input type="password" id="confirm_password" name="confirm_password" minlength="8" autocomplete="new-password" required>
          </div>
        </div>

        <label class="consent-row">
          <input type="checkbox" name="popia_consent" value="1" required>
          <span>I consent to my personal information being processed for learnership administration, SETA registration and B-BBEE skills development reporting, in line with the Protection of Personal Information Act (POPIA). <span class="required">*</span></span>
        </label>

        <button type="submit" class="btn btn-primary btn-block">Register</button>
      </form>

      <p class="auth-alt">Already registered? <a href="<?php echo html_escape(site_url('login.php')); ?>">Log in here</a></p>
    </div>
  </div>
</body>
</html>
