// Quiz page UX helpers. Grading happens on the server; this script only
// improves the form experience.
document.addEventListener('DOMContentLoaded', function () {
  var quizCard = document.querySelector('.exit-quiz-card');
  if (!quizCard) {
    return;
  }

  // Highlight the selected option in each question.
  quizCard.querySelectorAll('.question-options label').forEach(function (label) {
    var input = label.querySelector('input[type="radio"]');
    if (!input) {
      return;
    }
    input.addEventListener('change', function () {
      var group = label.closest('.question-options');
      group.querySelectorAll('label').forEach(function (other) {
        other.classList.remove('option-selected');
      });
      label.classList.add('option-selected');
    });
  });

  // Friendly check before submitting with unanswered questions
  // (server validates too - this just avoids a round trip).
  var form = quizCard.querySelector('form');
  if (form) {
    form.addEventListener('submit', function (event) {
      var unanswered = [];
      quizCard.querySelectorAll('.question-item').forEach(function (question, index) {
        if (!question.querySelector('input[type="radio"]:checked')) {
          unanswered.push(index + 1);
        }
      });
      if (unanswered.length > 0) {
        event.preventDefault();
        window.alert('Please answer question' + (unanswered.length > 1 ? 's ' : ' ') + unanswered.join(', ') + ' before submitting.');
      }
    });
  }
});
