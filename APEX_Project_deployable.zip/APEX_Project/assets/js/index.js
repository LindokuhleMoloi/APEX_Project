// Shared UI behaviour: mobile navigation toggle and flash message dismissal.
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('.nav-toggle').forEach(function (toggle) {
    toggle.addEventListener('click', function () {
      var nav = toggle.parentElement.querySelector('.nav-links');
      if (!nav) {
        return;
      }
      var open = nav.classList.toggle('nav-open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  });

  document.querySelectorAll('.flash-message').forEach(function (flash) {
    var close = document.createElement('button');
    close.type = 'button';
    close.className = 'flash-close';
    close.setAttribute('aria-label', 'Dismiss message');
    close.textContent = '×';
    close.addEventListener('click', function () {
      flash.remove();
    });
    flash.appendChild(close);

    window.setTimeout(function () {
      flash.classList.add('flash-fade');
      window.setTimeout(function () {
        flash.remove();
      }, 600);
    }, 8000);
  });
});
