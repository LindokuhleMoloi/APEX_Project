<?php
// My Documents: learners upload onboarding documents and assignment
// submissions, track review status, and download their own files.

require_once __DIR__ . '/includes/app.php';
require_once __DIR__ . '/includes/portal.php';
app_start();
require_user();

$db = db_connect();
$userId = (int) $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        flash_set('error', 'Your session expired. Please try again.');
        header('Location: ' . site_url('documents.php'));
        exit;
    }

    if (isset($_POST['upload_document'])) {
        $docType = sanitize_string($_POST['doc_type'] ?? '');
        $documentName = sanitize_string($_POST['document_name'] ?? '');

        if (!in_array($docType, portal_document_types(), true)) {
            flash_set('error', 'Please choose a valid document type.');
        } else {
            $stored = handle_file_upload($_FILES['document_file'] ?? [], 'documents');
            if (!$stored['ok']) {
                flash_set('error', $stored['error']);
            } else {
                if ($documentName === '') {
                    $documentName = $docType . ' - ' . $stored['original_name'];
                }
                if (portal_add_document($db, $userId, $docType, $documentName, $stored)) {
                    flash_set('success', 'Document uploaded successfully. The training provider will review it.');
                } else {
                    @unlink(UPLOADS_DIR . '/' . $stored['path']);
                    flash_set('error', 'Could not save the document record. Please try again.');
                }
            }
        }
    } elseif (isset($_POST['delete_document'])) {
        $documentId = (int) $_POST['delete_document'];
        if (portal_delete_document($db, $documentId, $userId)) {
            flash_set('success', 'Document deleted.');
        } else {
            flash_set('error', 'Only your own documents that are still pending review can be deleted.');
        }
    }

    header('Location: ' . site_url('documents.php'));
    exit;
}

$documents = portal_get_user_documents($db, $userId);
$docTypes = portal_document_types();

$requiredOnboarding = ['Certified ID Copy', 'CV / Resume', 'Proof of Residence'];
$uploadedTypes = array_column($documents, 'doc_type');
?>
<?php render_head('My Documents'); ?>
<body>
  <?php render_navigation(); ?>
  <div class="page-container">
    <?php render_flash_messages(); ?>
    <div class="section-header">
      <div>
        <h1>My Documents</h1>
        <p>Upload your learnership onboarding documents and assignment submissions, and track their review status.</p>
      </div>
    </div>

    <div class="dashboard">
      <div class="main-content">
        <div class="course-card">
          <h2>Upload a document</h2>
          <form method="post" enctype="multipart/form-data" class="upload-form">
            <?php echo csrf_input_field(); ?>
            <div class="form-grid">
              <div class="form-group">
                <label for="doc_type">Document type <span class="required">*</span></label>
                <select id="doc_type" name="doc_type" required>
                  <?php foreach ($docTypes as $type): ?>
                    <option value="<?php echo html_escape($type); ?>"><?php echo html_escape($type); ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="form-group">
                <label for="document_name">Description <span class="hint">(optional)</span></label>
                <input type="text" id="document_name" name="document_name" placeholder="e.g. Module 3 assignment">
              </div>
            </div>
            <div class="form-group file-upload">
              <label for="document_file">Choose file <span class="required">*</span></label>
              <input type="file" id="document_file" name="document_file" required>
              <small>Allowed: <?php echo html_escape(implode(', ', ALLOWED_UPLOAD_EXTENSIONS)); ?>.
                     Maximum size: <?php echo format_file_size(MAX_UPLOAD_BYTES); ?>.</small>
            </div>
            <button type="submit" name="upload_document" value="1" class="btn btn-primary">Upload document</button>
          </form>
          <p class="popia-note">&#128274; Your documents are stored securely, are only visible to you and the training
             provider, and are processed for learnership administration in line with POPIA.</p>
        </div>

        <div class="course-card">
          <h2>Your uploaded documents</h2>
          <?php if (empty($documents)): ?>
            <p>You have not uploaded any documents yet. Start with your onboarding documents listed on the right.</p>
          <?php else: ?>
            <table class="course-table documents-table">
              <tr>
                <th>Document</th>
                <th>Type</th>
                <th>Size</th>
                <th>Uploaded</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
              <?php foreach ($documents as $document): ?>
                <tr>
                  <td>
                    <?php echo html_escape($document['document_name']); ?>
                    <?php if (!empty($document['review_note'])): ?>
                      <div class="review-note">Note: <?php echo html_escape($document['review_note']); ?></div>
                    <?php endif; ?>
                  </td>
                  <td><?php echo html_escape($document['doc_type']); ?></td>
                  <td><?php echo format_file_size((int) $document['file_size']); ?></td>
                  <td><?php echo html_escape(date('d M Y', strtotime($document['upload_date']))); ?></td>
                  <td><span class="status-chip chip-<?php echo strtolower($document['status']); ?>"><?php echo html_escape($document['status']); ?></span></td>
                  <td class="table-actions">
                    <a class="btn btn-soft btn-small" href="<?php echo html_escape(site_url('download.php?type=document&id=' . (int) $document['id'])); ?>">Download</a>
                    <?php if ($document['status'] === 'Pending'): ?>
                      <form method="post" class="inline-form" onsubmit="return confirm('Delete this document?');">
                        <?php echo csrf_input_field(); ?>
                        <button type="submit" name="delete_document" value="<?php echo (int) $document['id']; ?>" class="btn btn-danger btn-small">Delete</button>
                      </form>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            </table>
          <?php endif; ?>
        </div>
      </div>

      <aside class="sidebar">
        <h3>Onboarding checklist</h3>
        <p>The training provider needs these documents to register you on the learnership:</p>
        <ul class="checklist">
          <?php foreach ($requiredOnboarding as $required): ?>
            <li class="<?php echo in_array($required, $uploadedTypes, true) ? 'check-done' : 'check-todo'; ?>">
              <?php echo in_array($required, $uploadedTypes, true) ? '&#9989;' : '&#11036;'; ?>
              <?php echo html_escape($required); ?>
            </li>
          <?php endforeach; ?>
        </ul>
        <h3>Tips</h3>
        <ul class="sidebar-tips">
          <li>Scan or photograph documents clearly - all corners visible.</li>
          <li>Certified copies must be stamped within the last 3 months.</li>
          <li>You can delete and re-upload a document while it is still pending review.</li>
        </ul>
      </aside>
    </div>
  </div>
  <?php render_page_footer(); ?>
</body>
</html>
