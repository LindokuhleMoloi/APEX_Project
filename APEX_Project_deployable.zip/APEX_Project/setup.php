<?php
/**
 * SS Learner Portal installer / upgrader.
 *
 * Creates the database schema on a fresh host and upgrades an existing
 * v1 ss_portal database in place (adds new columns/tables, repairs bad
 * registration statuses, hashes any plain-text admin passwords, seeds
 * the default admin account and qualifications). Safe to run repeatedly.
 *
 * Usage:
 *   CLI:  php setup.php
 *   Web:  set the SS_PORTAL_SETUP_KEY environment variable, then open
 *         setup.php?key=YOUR_KEY  (delete this file after deployment)
 */

require_once __DIR__ . '/includes/app.php';

$isCli = PHP_SAPI === 'cli';
if (!$isCli) {
    $setupKey = getenv('SS_PORTAL_SETUP_KEY');
    if (!$setupKey || !hash_equals($setupKey, $_GET['key'] ?? '')) {
        http_response_code(403);
        exit('Setup is locked. Run "php setup.php" from the command line, or set the SS_PORTAL_SETUP_KEY environment variable and pass ?key=...');
    }
    header('Content-Type: text/plain; charset=utf-8');
}

$report = [];
$note = function (string $line) use (&$report, $isCli) {
    $report[] = $line;
    echo $line . PHP_EOL;
    if (!$isCli) {
        @ob_flush();
        @flush();
    }
};

$note('SS Learner Portal setup starting (' . date('Y-m-d H:i:s') . ')');

// 1. Connect to the server and make sure the database exists.
mysqli_report(MYSQLI_REPORT_OFF);
$server = @new mysqli(DB_HOST, DB_USER, DB_PASS);
if ($server->connect_errno) {
    exit('Could not connect to MySQL server: ' . $server->connect_error . PHP_EOL);
}
$server->set_charset('utf8mb4');

if ($server->query("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci")) {
    $note('Database "' . DB_NAME . '" is ready.');
} else {
    $note('NOTE: could not create database (' . $server->error . '). Continuing in case it already exists.');
}
$server->select_db(DB_NAME);
$db = $server;

// 2. Create tables (matches ss_portal.sql).
$tables = [
    'admin' => "CREATE TABLE IF NOT EXISTS `admin` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `username` varchar(50) NOT NULL,
        `password` varchar(255) NOT NULL,
        PRIMARY KEY (`id`), UNIQUE KEY `username` (`username`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci",

    'users' => "CREATE TABLE IF NOT EXISTS `users` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `username` varchar(50) NOT NULL,
        `password` varchar(255) NOT NULL,
        `is_admin` tinyint(1) DEFAULT 0,
        `email` varchar(255) DEFAULT NULL,
        `full_name` varchar(150) DEFAULT NULL,
        `phone` varchar(20) DEFAULT NULL,
        `id_number` varchar(13) DEFAULT NULL,
        `avatar_path` varchar(255) DEFAULT NULL,
        `theme` varchar(20) NOT NULL DEFAULT 'default',
        `popia_consent` tinyint(1) NOT NULL DEFAULT 0,
        `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
        PRIMARY KEY (`id`), UNIQUE KEY `username` (`username`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci",

    'subjects' => "CREATE TABLE IF NOT EXISTS `subjects` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `name` varchar(100) NOT NULL,
        `code` varchar(20) DEFAULT NULL,
        `nqf_level` tinyint(4) DEFAULT NULL,
        `saqa_id` varchar(20) DEFAULT NULL,
        `credits` int(11) DEFAULT NULL,
        `duration_months` int(11) DEFAULT NULL,
        `seta` varchar(50) DEFAULT NULL,
        `description` text DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci",

    'registrations' => "CREATE TABLE IF NOT EXISTS `registrations` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `user_id` int(11) DEFAULT NULL,
        `subject_id` int(11) DEFAULT NULL,
        `status` enum('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
        `registration_date` timestamp NOT NULL DEFAULT current_timestamp(),
        `email` varchar(255) DEFAULT NULL,
        `decided_at` timestamp NULL DEFAULT NULL,
        PRIMARY KEY (`id`),
        KEY `user_id` (`user_id`), KEY `subject_id` (`subject_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci",

    'module_progress' => "CREATE TABLE IF NOT EXISTS `module_progress` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `user_id` int(11) NOT NULL,
        `module_number` tinyint(4) NOT NULL,
        `completed_at` timestamp NOT NULL DEFAULT current_timestamp(),
        PRIMARY KEY (`id`), UNIQUE KEY `user_module` (`user_id`, `module_number`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci",

    'quiz_attempts' => "CREATE TABLE IF NOT EXISTS `quiz_attempts` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `user_id` int(11) NOT NULL,
        `module_number` tinyint(4) NOT NULL,
        `score` int(11) NOT NULL,
        `total` int(11) NOT NULL,
        `percent` decimal(5,2) NOT NULL,
        `passed` tinyint(1) NOT NULL DEFAULT 0,
        `answers` text DEFAULT NULL,
        `attempted_at` timestamp NOT NULL DEFAULT current_timestamp(),
        PRIMARY KEY (`id`), KEY `user_module` (`user_id`, `module_number`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci",

    'learning_materials' => "CREATE TABLE IF NOT EXISTS `learning_materials` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `subject_id` int(11) DEFAULT NULL,
        `module_number` tinyint(4) DEFAULT NULL,
        `title` varchar(255) NOT NULL,
        `description` text DEFAULT NULL,
        `file_path` varchar(255) NOT NULL,
        `original_name` varchar(255) NOT NULL,
        `file_size` int(10) UNSIGNED NOT NULL DEFAULT 0,
        `mime_type` varchar(100) DEFAULT NULL,
        `uploaded_by` varchar(50) DEFAULT NULL,
        `upload_date` timestamp NOT NULL DEFAULT current_timestamp(),
        PRIMARY KEY (`id`), KEY `subject_id` (`subject_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci",

    'documents' => "CREATE TABLE IF NOT EXISTS `documents` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `user_id` int(11) DEFAULT NULL,
        `doc_type` varchar(50) NOT NULL DEFAULT 'Other',
        `document_name` varchar(255) NOT NULL,
        `file_path` varchar(255) NOT NULL,
        `original_name` varchar(255) DEFAULT NULL,
        `file_size` int(10) UNSIGNED NOT NULL DEFAULT 0,
        `mime_type` varchar(100) DEFAULT NULL,
        `status` enum('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
        `review_note` varchar(255) DEFAULT NULL,
        `upload_date` timestamp NOT NULL DEFAULT current_timestamp(),
        `reviewed_at` timestamp NULL DEFAULT NULL,
        PRIMARY KEY (`id`), KEY `user_id` (`user_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci",

    'announcements' => "CREATE TABLE IF NOT EXISTS `announcements` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `title` varchar(200) NOT NULL,
        `body` text NOT NULL,
        `created_by` varchar(50) DEFAULT NULL,
        `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci",
];

foreach ($tables as $name => $sql) {
    if ($db->query($sql)) {
        $note('Table "' . $name . '" is ready.');
    } else {
        $note('ERROR creating table "' . $name . '": ' . $db->error);
    }
}

// 3. Upgrade older installs: add any missing columns.
function column_exists(mysqli $db, string $table, string $column): bool
{
    $stmt = $db->prepare(
        "SELECT COUNT(*) AS c FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?");
    $schema = DB_NAME;
    $stmt->bind_param('sss', $schema, $table, $column);
    $stmt->execute();
    $exists = (int) $stmt->get_result()->fetch_assoc()['c'] > 0;
    $stmt->close();
    return $exists;
}

$columnUpgrades = [
    ['users', 'full_name', "ALTER TABLE `users` ADD `full_name` varchar(150) DEFAULT NULL"],
    ['users', 'phone', "ALTER TABLE `users` ADD `phone` varchar(20) DEFAULT NULL"],
    ['users', 'id_number', "ALTER TABLE `users` ADD `id_number` varchar(13) DEFAULT NULL"],
    ['users', 'avatar_path', "ALTER TABLE `users` ADD `avatar_path` varchar(255) DEFAULT NULL"],
    ['users', 'theme', "ALTER TABLE `users` ADD `theme` varchar(20) NOT NULL DEFAULT 'default'"],
    ['users', 'popia_consent', "ALTER TABLE `users` ADD `popia_consent` tinyint(1) NOT NULL DEFAULT 0"],
    ['users', 'created_at', "ALTER TABLE `users` ADD `created_at` timestamp NOT NULL DEFAULT current_timestamp()"],
    ['subjects', 'code', "ALTER TABLE `subjects` ADD `code` varchar(20) DEFAULT NULL"],
    ['subjects', 'nqf_level', "ALTER TABLE `subjects` ADD `nqf_level` tinyint(4) DEFAULT NULL"],
    ['subjects', 'saqa_id', "ALTER TABLE `subjects` ADD `saqa_id` varchar(20) DEFAULT NULL"],
    ['subjects', 'credits', "ALTER TABLE `subjects` ADD `credits` int(11) DEFAULT NULL"],
    ['subjects', 'duration_months', "ALTER TABLE `subjects` ADD `duration_months` int(11) DEFAULT NULL"],
    ['subjects', 'seta', "ALTER TABLE `subjects` ADD `seta` varchar(50) DEFAULT NULL"],
    ['subjects', 'description', "ALTER TABLE `subjects` ADD `description` text DEFAULT NULL"],
    ['registrations', 'decided_at', "ALTER TABLE `registrations` ADD `decided_at` timestamp NULL DEFAULT NULL"],
    ['documents', 'doc_type', "ALTER TABLE `documents` ADD `doc_type` varchar(50) NOT NULL DEFAULT 'Other' AFTER `user_id`"],
    ['documents', 'original_name', "ALTER TABLE `documents` ADD `original_name` varchar(255) DEFAULT NULL"],
    ['documents', 'file_size', "ALTER TABLE `documents` ADD `file_size` int(10) UNSIGNED NOT NULL DEFAULT 0"],
    ['documents', 'mime_type', "ALTER TABLE `documents` ADD `mime_type` varchar(100) DEFAULT NULL"],
    ['documents', 'status', "ALTER TABLE `documents` ADD `status` enum('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending'"],
    ['documents', 'review_note', "ALTER TABLE `documents` ADD `review_note` varchar(255) DEFAULT NULL"],
    ['documents', 'reviewed_at', "ALTER TABLE `documents` ADD `reviewed_at` timestamp NULL DEFAULT NULL"],
];

foreach ($columnUpgrades as [$table, $column, $sql]) {
    if (!column_exists($db, $table, $column)) {
        if ($db->query($sql)) {
            $note('Added column ' . $table . '.' . $column . '.');
        } else {
            $note('ERROR adding column ' . $table . '.' . $column . ': ' . $db->error);
        }
    }
}

// 4. Repair registration statuses written by the old dashboard bug
//    ("Accepted" was not a valid enum value and was stored as '').
$db->query("UPDATE registrations SET status = 'Approved' WHERE status = '' OR status IS NULL");
if ($db->affected_rows > 0) {
    $note('Repaired ' . $db->affected_rows . ' registration status value(s) from the legacy "Accepted" bug.');
}

// 5. Hash any plain-text admin passwords left over from the v1 dump.
$result = $db->query("SELECT id, password FROM admin");
$hashed = 0;
while ($result && ($row = $result->fetch_assoc())) {
    $info = password_get_info($row['password']);
    if (empty($info['algo'])) {
        $newHash = password_hash($row['password'], PASSWORD_DEFAULT);
        $stmt = $db->prepare("UPDATE admin SET password = ? WHERE id = ?");
        $stmt->bind_param('si', $newHash, $row['id']);
        $stmt->execute();
        $stmt->close();
        $hashed++;
    }
}
if ($hashed > 0) {
    $note('Hashed ' . $hashed . ' plain-text admin password(s).');
}

// 6. Seed default data.
$adminCount = (int) $db->query("SELECT COUNT(*) AS c FROM admin")->fetch_assoc()['c'];
if ($adminCount === 0) {
    $defaultHash = password_hash('Admin@123', PASSWORD_DEFAULT);
    $stmt = $db->prepare("INSERT INTO admin (username, password) VALUES ('admin', ?)");
    $stmt->bind_param('s', $defaultHash);
    $stmt->execute();
    $stmt->close();
    $note('Seeded default admin account: admin / Admin@123 (CHANGE THIS PASSWORD IMMEDIATELY).');
}

$seedSubjects = [
    ['End User Computing NQF3', 'EUC-NQF3', 3, '49077', 130, 12, 'MICT SETA',
     'National Certificate: Information Technology: End User Computing. Builds confident, work-ready computer skills: office productivity tools, internet and email, file management and digital workplace literacy.'],
    ['Software Development NQF4', 'SD-NQF4', 4, '78964', 163, 12, 'MICT SETA',
     'Further Education and Training Certificate: Information Technology: Systems Development. Introduces programming logic, databases, web development and the software development life cycle.'],
];

foreach ($seedSubjects as [$name, $code, $nqf, $saqa, $credits, $months, $seta, $description]) {
    $stmt = $db->prepare("SELECT id FROM subjects WHERE name = ? LIMIT 1");
    $stmt->bind_param('s', $name);
    $stmt->execute();
    $existing = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($existing) {
        $stmt = $db->prepare(
            "UPDATE subjects SET code = ?, nqf_level = ?, saqa_id = ?, credits = ?, duration_months = ?, seta = ?,
                    description = COALESCE(description, ?)
             WHERE id = ?");
        $stmt->bind_param('sisiissi', $code, $nqf, $saqa, $credits, $months, $seta, $description, $existing['id']);
        $stmt->execute();
        $stmt->close();
        $note('Updated qualification details for "' . $name . '".');
    } else {
        $stmt = $db->prepare(
            "INSERT INTO subjects (name, code, nqf_level, saqa_id, credits, duration_months, seta, description)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param('ssisiiss', $name, $code, $nqf, $saqa, $credits, $months, $seta, $description);
        $stmt->execute();
        $stmt->close();
        $note('Seeded qualification "' . $name . '".');
    }
}

$announcementCount = (int) $db->query("SELECT COUNT(*) AS c FROM announcements")->fetch_assoc()['c'];
if ($announcementCount === 0) {
    $stmt = $db->prepare("INSERT INTO announcements (title, body, created_by) VALUES (?, ?, 'admin')");
    $title = 'Welcome to the SS Learner Portal';
    $body = 'Welcome to your learnership journey! Work through the modules in order, download your learning materials from the Materials page, and upload your onboarding documents (certified ID copy, CV and proof of residence) under My Documents. Contact your training coordinator if you need help.';
    $stmt->bind_param('ss', $title, $body);
    $stmt->execute();
    $stmt->close();
    $note('Seeded welcome announcement.');
}

$note('Setup complete. ' . ($isCli ? '' : 'Remember to DELETE setup.php (or unset SS_PORTAL_SETUP_KEY) on production.'));
