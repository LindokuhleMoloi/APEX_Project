<?php
// Secure download endpoint for all stored files.
//
//   download.php?type=material&id=N   learning material (enrolled learners + admins)
//   download.php?type=document&id=N   learner document (owner or admin only)
//   download.php?type=avatar&id=N     profile avatar (any logged-in user, shown inline)

require_once __DIR__ . '/includes/app.php';
require_once __DIR__ . '/includes/portal.php';
app_start();

$isAdmin = is_admin_logged_in();
$isUser = is_user_logged_in();

if (!$isAdmin && !$isUser) {
    header('Location: ' . site_url('login.php'));
    exit;
}

$db = db_connect();
$type = $_GET['type'] ?? '';
$id = (int) ($_GET['id'] ?? 0);
$userId = (int) ($_SESSION['user_id'] ?? 0);

switch ($type) {
    case 'material':
        $material = portal_get_material($db, $id);
        if (!$material) {
            http_response_code(404);
            exit('Material not found.');
        }

        if (!$isAdmin) {
            // Course-specific materials require an approved registration on that course.
            if ($material['subject_id'] !== null) {
                $allowed = false;
                foreach (portal_get_user_registrations($db, $userId) as $registration) {
                    if ((int) $registration['subject_id'] === (int) $material['subject_id'] && $registration['status'] === 'Approved') {
                        $allowed = true;
                        break;
                    }
                }
                if (!$allowed) {
                    http_response_code(403);
                    exit('This material belongs to a course you are not enrolled in yet.');
                }
            }
        }

        log_request('download material=' . $id . ' user=' . ($userId ?: 'admin'));
        stream_stored_file($material['file_path'], $material['original_name'], $material['mime_type'] ?: 'application/octet-stream');
        break;

    case 'document':
        $document = portal_get_document($db, $id);
        if (!$document) {
            http_response_code(404);
            exit('Document not found.');
        }
        if (!$isAdmin && (int) $document['user_id'] !== $userId) {
            http_response_code(403);
            exit('You can only download your own documents.');
        }

        log_request('download document=' . $id . ' user=' . ($userId ?: 'admin'));
        stream_stored_file($document['file_path'], $document['original_name'] ?: $document['document_name'], $document['mime_type'] ?: 'application/octet-stream');
        break;

    case 'avatar':
        $stmt = $db->prepare("SELECT avatar_path FROM users WHERE id = ? LIMIT 1");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$row || empty($row['avatar_path'])) {
            http_response_code(404);
            exit('Avatar not found.');
        }

        $extension = strtolower(pathinfo($row['avatar_path'], PATHINFO_EXTENSION));
        $mime = ['png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'gif' => 'image/gif'][$extension] ?? 'application/octet-stream';
        stream_stored_file($row['avatar_path'], 'avatar.' . $extension, $mime, true);
        break;

    default:
        http_response_code(400);
        exit('Unknown download type.');
}
