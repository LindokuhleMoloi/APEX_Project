<?php
// Admin: upload and manage downloadable learning materials.

require_once __DIR__ . '/includes/app.php';
require_once __DIR__ . '/includes/portal.php';
require_once __DIR__ . '/includes/module_template.php';
app_start();
require_admin();

$db = db_connect();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        flash_set('error', 'Your session expired. Please try again.');
        header('Location: ' . site_url('admin_materials.php'));
        exit;
    }

    if (isset($_POST['upload_material'])) {
        $title = sanitize_string($_POST['title'] ?? '');
        $description = sanitize_string($_POST['description'] ?? '');
        $subjectId = (int) ($_POST['subject_id'] ?? 0) ?: null;
        $moduleNumber = (int) ($_POST['module_number'] ?? 0) ?: null;

        if (!$title) {
            flash_set('error', 'Please provide a title for the material.');
        } else {
            $stored = handle_file_upload($_FILES['material_file'] ?? [], 'materials', null, 50 * 1024 * 1024);
            if (!$stored['ok']) {
                flash_set('error', $stored['error']);
            } elseif (portal_add_material($db, $subjectId, $moduleNumber, $title, $description, $stored, $_SESSION['admin_username'] ?? 'admin')) {
                flash_set('success', 'Material "' . $title . '" published. Learners can download it now.');
            } else {
                @unlink(UPLOADS_DIR . '/' . $stored['path']);
                flash_set('error', 'Could not save the material record.');
            }
        }
    } elseif (isset($_POST['delete_material'])) {
        if (portal_delete_material($db, (int) $_POST['delete_material'])) {
            flash_set('success', 'Material deleted.');
        } else {
            flash_set('error', 'Material not found.');
        }
    }

    header('Location: ' . site_url('admin_materials.php'));
    exit;
}

$courses = portal_get_courses($db);
$materials = portal_get_materials($db);
$moduleMeta = get_module_metadata();
?>
<?php render_head('Learning Materials Admin'); ?>
<body class="admin-body">
  <?php render_admin_navigation(); ?>
  <div class="page-container">
    <?php render_flash_messages(); ?>
    <div class="section-header">
      <div>
        <h1>Learning Materials</h1>
        <p>Upload study guides, slides and exercises. Learners download them from the Materials page and inside each module.</p>
      </div>
    </div>

    <div class="course-card">
      <h2>Publish new material</h2>
      <form method="post" enctype="multipart/form-data">
        <?php echo csrf_input_field(); ?>
        <div class="form-grid">
          <div class="form-group">
            <label for="title">Title <span class="required">*</span></label>
            <input type="text" id="title" name="title" placeholder="e.g. Module 1 Study Guide" required>
          </div>
          <div class="form-group">
            <label for="description">Description</label>
            <input type="text" id="description" name="description" placeholder="Short description shown to learners">
          </div>
        </div>
        <div class="form-grid">
          <div class="form-group">
            <label for="subject_id">Course</label>
            <select id="subject_id" name="subject_id">
              <option value="0">All courses (general)</option>
              <?php foreach ($courses as $course): ?>
                <option value="<?php echo (int) $course['id']; ?>"><?php echo html_escape($course['name']); ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label for="module_number">Module</label>
            <select id="module_number" name="module_number">
              <option value="0">General (no specific module)</option>
              <?php foreach ($moduleMeta as $id => $module): ?>
                <option value="<?php echo $id; ?>">Module <?php echo $id; ?>: <?php echo html_escape($module['title']); ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>
        <div class="form-group file-upload">
          <label for="material_file">File <span class="required">*</span></label>
          <input type="file" id="material_file" name="material_file" required>
          <small>Allowed: <?php echo html_escape(implode(', ', ALLOWED_UPLOAD_EXTENSIONS)); ?>. Maximum size: 50 MB.</small>
        </div>
        <button type="submit" name="upload_material" value="1" class="btn btn-primary">Publish material</button>
      </form>
    </div>

    <div class="course-card">
      <h2>Published materials (<?php echo count($materials); ?>)</h2>
      <?php if (empty($materials)): ?>
        <p>No materials published yet. Upload the first study guide above.</p>
      <?php else: ?>
        <table class="course-table">
          <tr>
            <th>Title</th>
            <th>Course</th>
            <th>Module</th>
            <th>File</th>
            <th>Size</th>
            <th>Uploaded</th>
            <th>Actions</th>
          </tr>
          <?php foreach ($materials as $material): ?>
            <tr>
              <td><?php echo html_escape($material['title']); ?></td>
              <td><?php echo html_escape($material['subject_name'] ?? 'All courses'); ?></td>
              <td><?php echo $material['module_number'] ? 'Module ' . (int) $material['module_number'] : 'General'; ?></td>
              <td><?php echo html_escape($material['original_name']); ?></td>
              <td><?php echo format_file_size((int) $material['file_size']); ?></td>
              <td><?php echo html_escape(date('d M Y', strtotime($material['upload_date']))); ?> <span class="muted">by <?php echo html_escape($material['uploaded_by'] ?? '-'); ?></span></td>
              <td class="table-actions">
                <a class="btn btn-soft btn-small" href="<?php echo html_escape(site_url('download.php?type=material&id=' . (int) $material['id'])); ?>">Download</a>
                <form method="post" class="inline-form" onsubmit="return confirm('Delete this material? Learners will no longer be able to download it.');">
                  <?php echo csrf_input_field(); ?>
                  <button type="submit" name="delete_material" value="<?php echo (int) $material['id']; ?>" class="btn btn-danger btn-small">Delete</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </table>
      <?php endif; ?>
    </div>
  </div>
  <?php render_page_footer(); ?>
</body>
</html>
