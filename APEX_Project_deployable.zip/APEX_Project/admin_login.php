<?php
require_once __DIR__ . '/includes/app.php';
app_start();

if (is_admin_logged_in()) {
    header('Location: ' . site_url('dashboard.php'));
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = 'Your session expired. Please try again.';
    } else {
        $mysqli = db_connect();
        $username = sanitize_string($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        $stmt = $mysqli->prepare("SELECT password FROM admin WHERE username = ? LIMIT 1");
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $stmt->store_result();

        $valid = false;
        if ($stmt->num_rows === 1) {
            $stmt->bind_result($hashed_password);
            $stmt->fetch();
            $valid = password_verify($password, $hashed_password);
        }
        $stmt->close();

        if ($valid) {
            session_regenerate_id(true);
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_username'] = $username;
            header('Location: ' . site_url('dashboard.php'));
            exit;
        }

        $error = 'Invalid username or password.';
        log_request('failed_admin_login user=' . $username);
    }
}
?>
<?php render_head('Admin Login'); ?>
<body class="auth-body auth-body-admin">
  <div class="auth-wrapper">
    <div class="auth-card">
      <div class="auth-brand">
        <div class="auth-logo auth-logo-admin">SS</div>
        <h1>Training Provider Login</h1>
        <p>Administration access for coordinators and facilitators.</p>
      </div>

      <?php if ($error): ?>
        <div class="flash-message flash-error" role="alert"><?php echo html_escape($error); ?></div>
      <?php endif; ?>

      <form method="post" action="" class="auth-form">
        <?php echo csrf_input_field(); ?>
        <div class="form-group">
          <label for="username">Username</label>
          <input type="text" id="username" name="username" autocomplete="username" required autofocus>
        </div>
        <div class="form-group">
          <label for="password">Password</label>
          <input type="password" id="password" name="password" autocomplete="current-password" required>
        </div>
        <button type="submit" name="login" value="1" class="btn btn-primary btn-block">Login</button>
      </form>

      <p class="auth-alt auth-alt-small">New admin accounts are created by an existing administrator on the dashboard.</p>
      <p class="auth-alt"><a href="<?php echo html_escape(site_url('login.php')); ?>">&larr; Learner login</a></p>
    </div>
  </div>
</body>
</html>
