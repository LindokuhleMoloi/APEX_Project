<?php
require_once __DIR__ . '/includes/app.php';
app_start();

if (is_user_logged_in()) {
    header('Location: ' . site_url('index.php'));
    exit;
}

$login_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $login_msg = 'Your session expired. Please try again.';
    } else {
        $mysqli = db_connect();
        $username = sanitize_string($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        $stmt = $mysqli->prepare("SELECT id, password, full_name FROM users WHERE username = ? LIMIT 1");
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();

        if ($user && password_verify($password, $user['password'])) {
            // Prefer the approved course for the session subject line.
            $stmt2 = $mysqli->prepare(
                "SELECT s.name FROM registrations r
                 JOIN subjects s ON r.subject_id = s.id
                 WHERE r.user_id = ?
                 ORDER BY (r.status = 'Approved') DESC, r.registration_date DESC
                 LIMIT 1");
            $stmt2->bind_param('i', $user['id']);
            $stmt2->execute();
            $stmt2->bind_result($subject_name);
            $stmt2->fetch();
            $stmt2->close();

            session_regenerate_id(true);
            $_SESSION['user_id'] = (int) $user['id'];
            $_SESSION['username'] = $username;
            $_SESSION['full_name'] = $user['full_name'] ?: $username;
            $_SESSION['subject'] = $subject_name ?: 'No Subject';

            header('Location: ' . site_url('index.php'));
            exit;
        }

        $login_msg = 'Invalid username or password.';
        log_request('failed_login user=' . $username);
    }
}
?>
<?php render_head('Login'); ?>
<body class="auth-body">
  <div class="auth-wrapper">
    <div class="auth-card">
      <div class="auth-brand">
        <div class="auth-logo">SS</div>
        <h1><?php echo html_escape(APP_NAME); ?></h1>
        <p>Sign in to continue your learnership journey.</p>
      </div>

      <?php if ($login_msg): ?>
        <div class="flash-message flash-error" role="alert"><?php echo html_escape($login_msg); ?></div>
      <?php endif; ?>
      <?php render_flash_messages(); ?>

      <form method="post" class="auth-form">
        <?php echo csrf_input_field(); ?>
        <div class="form-group">
          <label for="username">Username</label>
          <input type="text" id="username" name="username" autocomplete="username" required autofocus>
        </div>
        <div class="form-group">
          <label for="password">Password</label>
          <input type="password" id="password" name="password" autocomplete="current-password" required>
        </div>
        <button type="submit" name="login" value="1" class="btn btn-primary btn-block">Login</button>
      </form>

      <p class="auth-alt">New learner? <a href="<?php echo html_escape(site_url('register.php')); ?>">Create your account</a></p>
      <p class="auth-alt auth-alt-small"><a href="<?php echo html_escape(site_url('admin_login.php')); ?>">Training provider / admin login</a></p>
    </div>
  </div>
</body>
</html>
