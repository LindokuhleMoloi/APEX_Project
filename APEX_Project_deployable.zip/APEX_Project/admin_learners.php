<?php
// Admin: learner management - search, progress overview, detail view and
// password resets.

require_once __DIR__ . '/includes/app.php';
require_once __DIR__ . '/includes/portal.php';
require_once __DIR__ . '/includes/module_template.php';
app_start();
require_admin();

$db = db_connect();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        flash_set('error', 'Your session expired. Please try again.');
        header('Location: ' . site_url('admin_learners.php'));
        exit;
    }

    if (isset($_POST['reset_password'], $_POST['learner_id'])) {
        $learnerId = (int) $_POST['learner_id'];
        $learner = portal_get_learner($db, $learnerId);
        if ($learner) {
            $tempPassword = 'Learn@' . random_int(100000, 999999);
            $hash = password_hash($tempPassword, PASSWORD_DEFAULT);
            $stmt = $db->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->bind_param('si', $hash, $learnerId);
            $stmt->execute();
            $stmt->close();
            flash_set('success', 'Temporary password for ' . $learner['username'] . ': ' . $tempPassword . ' - share it securely and ask the learner to change it after login.');
        } else {
            flash_set('error', 'Learner not found.');
        }
        header('Location: ' . site_url('admin_learners.php?view=' . $learnerId));
        exit;
    }
}

$search = sanitize_string($_GET['q'] ?? '');
$viewId = (int) ($_GET['view'] ?? 0);
$learnerDetail = $viewId ? portal_get_learner($db, $viewId) : null;
?>
<?php render_head('Learners'); ?>
<body class="admin-body">
  <?php render_admin_navigation(); ?>
  <div class="page-container">
    <?php render_flash_messages(); ?>

    <?php if ($learnerDetail): ?>
      <?php
        $registrations = portal_get_user_registrations($db, $viewId);
        $attempts = portal_get_quiz_attempts($db, $viewId);
        $documents = portal_get_user_documents($db, $viewId);
        $best = portal_get_best_attempts($db, $viewId);
        $progress = portal_overall_progress_percent($db, $viewId);
        $moduleMeta = get_module_metadata();
      ?>
      <div class="section-header">
        <div>
          <h1><?php echo html_escape($learnerDetail['full_name'] ?: $learnerDetail['username']); ?></h1>
          <p>Username: <strong><?php echo html_escape($learnerDetail['username']); ?></strong>
             &middot; Email: <?php echo html_escape($learnerDetail['email'] ?? '-'); ?>
             &middot; Phone: <?php echo html_escape($learnerDetail['phone'] ?? '-'); ?>
             &middot; Joined: <?php echo html_escape(date('d M Y', strtotime($learnerDetail['created_at']))); ?></p>
        </div>
        <a href="<?php echo html_escape(site_url('admin_learners.php')); ?>" class="btn btn-soft">&larr; All learners</a>
      </div>

      <div class="stat-grid">
        <div class="stat-card"><span class="stat-number"><?php echo $progress; ?>%</span><span class="stat-label">Modules passed</span></div>
        <div class="stat-card"><span class="stat-number"><?php echo count($attempts); ?></span><span class="stat-label">Quiz attempts</span></div>
        <div class="stat-card"><span class="stat-number"><?php echo count($documents); ?></span><span class="stat-label">Documents uploaded</span></div>
      </div>

      <div class="course-card">
        <h2>Course registrations</h2>
        <?php if (empty($registrations)): ?>
          <p>No course registrations.</p>
        <?php else: ?>
          <table class="course-table">
            <tr><th>Course</th><th>Status</th><th>Requested</th></tr>
            <?php foreach ($registrations as $registration): ?>
              <tr>
                <td><?php echo html_escape($registration['name']); ?></td>
                <td><span class="status-chip chip-<?php echo strtolower($registration['status']); ?>"><?php echo html_escape($registration['status']); ?></span></td>
                <td><?php echo html_escape($registration['registration_date']); ?></td>
              </tr>
            <?php endforeach; ?>
          </table>
        <?php endif; ?>
      </div>

      <div class="course-card">
        <h2>Module results</h2>
        <table class="course-table">
          <tr><th>Module</th><th>Best result</th><th>Attempts</th><th>Outcome</th></tr>
          <?php foreach ($moduleMeta as $id => $module): ?>
            <?php $b = $best[$id] ?? null; ?>
            <tr>
              <td>Module <?php echo $id; ?>: <?php echo html_escape($module['title']); ?></td>
              <td><?php echo $b ? number_format((float) $b['best_percent'], 0) . '%' : '-'; ?></td>
              <td><?php echo $b ? (int) $b['attempts'] : 0; ?></td>
              <td><?php echo $b ? (((int) $b['passed']) === 1 ? 'Competent' : 'Not yet competent') : 'Not attempted'; ?></td>
            </tr>
          <?php endforeach; ?>
        </table>
      </div>

      <div class="course-card">
        <h2>Documents</h2>
        <?php if (empty($documents)): ?>
          <p>No documents uploaded.</p>
        <?php else: ?>
          <table class="course-table">
            <tr><th>Document</th><th>Type</th><th>Status</th><th>Uploaded</th><th></th></tr>
            <?php foreach ($documents as $document): ?>
              <tr>
                <td><?php echo html_escape($document['document_name']); ?></td>
                <td><?php echo html_escape($document['doc_type']); ?></td>
                <td><span class="status-chip chip-<?php echo strtolower($document['status']); ?>"><?php echo html_escape($document['status']); ?></span></td>
                <td><?php echo html_escape(date('d M Y', strtotime($document['upload_date']))); ?></td>
                <td><a class="btn btn-soft btn-small" href="<?php echo html_escape(site_url('download.php?type=document&id=' . (int) $document['id'])); ?>">Download</a></td>
              </tr>
            <?php endforeach; ?>
          </table>
        <?php endif; ?>
        <p><a class="btn btn-soft" href="<?php echo html_escape(site_url('admin_documents.php')); ?>">Review documents</a></p>
      </div>

      <div class="course-card">
        <h2>Account actions</h2>
        <form method="post" class="inline-form" onsubmit="return confirm('Reset this learner\'s password to a temporary one?');">
          <?php echo csrf_input_field(); ?>
          <input type="hidden" name="learner_id" value="<?php echo $viewId; ?>">
          <button type="submit" name="reset_password" value="1" class="btn btn-secondary">Reset password</button>
        </form>
      </div>

    <?php else: ?>
      <div class="section-header">
        <div>
          <h1>Learners</h1>
          <p>All registered learners on the programme.</p>
        </div>
        <form method="get" class="search-form">
          <input type="search" name="q" value="<?php echo html_escape($search); ?>" placeholder="Search name, username or email">
          <button type="submit" class="btn btn-primary">Search</button>
        </form>
      </div>

      <div class="course-card">
        <?php $learners = portal_get_learners($db, $search); ?>
        <?php if (empty($learners)): ?>
          <p>No learners found<?php echo $search ? ' for "' . html_escape($search) . '"' : ''; ?>.</p>
        <?php else: ?>
          <table class="course-table">
            <tr>
              <th>Learner</th>
              <th>Email</th>
              <th>Course</th>
              <th>Status</th>
              <th>Joined</th>
              <th></th>
            </tr>
            <?php foreach ($learners as $learner): ?>
              <tr>
                <td><?php echo html_escape($learner['full_name'] ?: $learner['username']); ?> <span class="muted">(<?php echo html_escape($learner['username']); ?>)</span></td>
                <td><?php echo html_escape($learner['email'] ?? '-'); ?></td>
                <td><?php echo html_escape($learner['course_name'] ?? '-'); ?></td>
                <td>
                  <?php if ($learner['registration_status']): ?>
                    <span class="status-chip chip-<?php echo strtolower($learner['registration_status']); ?>"><?php echo html_escape($learner['registration_status']); ?></span>
                  <?php else: ?>
                    <span class="status-chip chip-none">No course</span>
                  <?php endif; ?>
                </td>
                <td><?php echo html_escape(date('d M Y', strtotime($learner['created_at']))); ?></td>
                <td><a class="btn btn-soft btn-small" href="<?php echo html_escape(site_url('admin_learners.php?view=' . (int) $learner['id'])); ?>">View</a></td>
              </tr>
            <?php endforeach; ?>
          </table>
        <?php endif; ?>
      </div>
    <?php endif; ?>
  </div>
  <?php render_page_footer(); ?>
</body>
</html>
