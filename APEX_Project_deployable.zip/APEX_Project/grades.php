<?php
require_once __DIR__ . '/includes/app.php';
require_once __DIR__ . '/includes/portal.php';
require_once __DIR__ . '/includes/module_template.php';
app_start();
require_user();

$mysqli = db_connect();
$user_id = (int) $_SESSION['user_id'];

$stmt = $mysqli->prepare(
    "SELECT u.username, u.full_name, u.email, s.name AS subject_name, r.status
     FROM users u
     LEFT JOIN registrations r ON u.id = r.user_id AND r.status = 'Approved'
     LEFT JOIN subjects s ON r.subject_id = s.id
     WHERE u.id = ?
     LIMIT 1");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

$moduleMeta = get_module_metadata();
$bestAttempts = portal_get_best_attempts($mysqli, $user_id);
$allAttempts = portal_get_quiz_attempts($mysqli, $user_id);
$progressPercent = portal_overall_progress_percent($mysqli, $user_id);

// Build per-module rows
$moduleRows = [];
$percentSum = 0.0;
$gradedModules = 0;
foreach ($moduleMeta as $id => $module) {
    $best = $bestAttempts[$id] ?? null;
    if ($best) {
        $percentSum += (float) $best['best_percent'];
        $gradedModules++;
    }
    $moduleRows[] = [
        'module' => $id,
        'title' => $module['title'],
        'best_percent' => $best ? (float) $best['best_percent'] : null,
        'attempts' => $best ? (int) $best['attempts'] : 0,
        'passed' => $best ? ((int) $best['passed'] === 1) : false,
    ];
}
$averagePercent = $gradedModules > 0 ? $percentSum / $gradedModules : null;

// CSV statement of results download
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="statement_of_results_' . preg_replace('/[^a-z0-9_-]/i', '_', $_SESSION['username']) . '.csv"');

    $output = fopen('php://output', 'w');
    fputcsv($output, ['Statement of Results - ' . APP_NAME]);
    fputcsv($output, ['Learner', $user['full_name'] ?: $user['username']]);
    fputcsv($output, ['Username', $user['username']]);
    fputcsv($output, ['Qualification', $user['subject_name'] ?? 'Not yet approved']);
    fputcsv($output, ['Generated', date('Y-m-d H:i')]);
    fputcsv($output, []);
    fputcsv($output, ['Module', 'Title', 'Best Result (%)', 'Attempts', 'Outcome']);
    foreach ($moduleRows as $row) {
        fputcsv($output, [
            'Module ' . $row['module'],
            $row['title'],
            $row['best_percent'] !== null ? number_format($row['best_percent'], 0) : 'Not attempted',
            $row['attempts'],
            $row['best_percent'] === null ? '-' : ($row['passed'] ? 'Competent (passed)' : 'Not yet competent'),
        ]);
    }
    fputcsv($output, []);
    fputcsv($output, ['Overall progress', $progressPercent . '% of modules passed']);
    if ($averagePercent !== null) {
        fputcsv($output, ['Average best result', number_format($averagePercent, 1) . '%']);
    }
    fclose($output);
    exit;
}

$grade_message = 'Pass each module exit quiz with ' . QUIZ_PASS_MARK . '% or more to be marked competent.';
if ($user && empty($user['subject_name'])) {
    $grade_message = 'Your course registration has not been approved yet. You can still work through the modules; results are recorded immediately.';
}

$avatarInitials = strtoupper(substr($user['full_name'] ?: ($user['username'] ?? $_SESSION['username']), 0, 1));
?>
<?php render_head('Grades'); ?>
<body>
  <?php render_navigation(); ?>
  <div class="page-container">
    <?php render_flash_messages(); ?>
    <div class="avatar-section">
      <div class="avatar-placeholder"><?php echo html_escape($avatarInitials); ?></div>
      <div>
        <h1>Grade Dashboard</h1>
        <p>Welcome back, <strong><?php echo html_escape($user['full_name'] ?: $user['username']); ?></strong>.
           Track your module results and overall progress here.</p>
      </div>
      <div class="section-header-action">
        <a href="<?php echo html_escape(site_url('grades.php?export=csv')); ?>" class="btn btn-secondary">&#11015;&#65039; Download statement of results (CSV)</a>
      </div>
    </div>

    <div class="info-panel">
      <h2>Current Summary</h2>
      <p><strong>Qualification:</strong> <?php echo html_escape($user['subject_name'] ?? 'No approved course yet'); ?></p>
      <p><strong>Overall progress:</strong> <?php echo $progressPercent; ?>% of modules passed
        <?php if ($averagePercent !== null): ?>
          &middot; <strong>Average best result:</strong> <?php echo number_format($averagePercent, 1); ?>%
        <?php endif; ?>
      </p>
      <div class="alert-box"><strong>How grading works:</strong> <?php echo html_escape($grade_message); ?></div>
    </div>

    <h2>Module Results</h2>
    <?php foreach ($moduleRows as $row): ?>
      <div class="progress-row">
        <div class="progress-title">
          Module <?php echo $row['module']; ?> &ndash; <?php echo html_escape($row['title']); ?>
          <?php if ($row['best_percent'] !== null): ?>
            <span class="status-chip <?php echo $row['passed'] ? 'chip-approved' : 'chip-rejected'; ?>">
              <?php echo $row['passed'] ? 'Competent' : 'Not yet competent'; ?>
            </span>
          <?php endif; ?>
        </div>
        <div class="progress-value">
          <?php echo $row['best_percent'] !== null ? number_format($row['best_percent'], 0) . '%' : 'Not attempted'; ?>
          <?php if ($row['attempts'] > 0): ?>
            <span class="attempt-count">(<?php echo $row['attempts']; ?> attempt<?php echo $row['attempts'] > 1 ? 's' : ''; ?>)</span>
          <?php endif; ?>
        </div>
      </div>
      <div class="progress-bar-bg">
        <div class="progress-bar-fill<?php echo $row['best_percent'] !== null && !$row['passed'] ? ' progress-bar-warn' : ''; ?>" style="width: <?php echo $row['best_percent'] !== null ? (int) $row['best_percent'] : 0; ?>%;"></div>
      </div>
    <?php endforeach; ?>

    <?php if (!empty($allAttempts)): ?>
      <div class="course-card">
        <h2>Recent quiz attempts</h2>
        <table class="course-table">
          <tr><th>Date</th><th>Module</th><th>Score</th><th>Percent</th><th>Result</th></tr>
          <?php foreach (array_slice($allAttempts, 0, 15) as $attempt): ?>
            <tr>
              <td><?php echo html_escape($attempt['attempted_at']); ?></td>
              <td>Module <?php echo (int) $attempt['module_number']; ?></td>
              <td><?php echo (int) $attempt['score']; ?>/<?php echo (int) $attempt['total']; ?></td>
              <td><?php echo number_format((float) $attempt['percent'], 0); ?>%</td>
              <td><?php echo ((int) $attempt['passed']) === 1 ? 'Passed' : 'Not passed'; ?></td>
            </tr>
          <?php endforeach; ?>
        </table>
      </div>
    <?php endif; ?>

    <div class="course-card">
      <h2>What to do next</h2>
      <ul>
        <li>Retake any quiz where you are "Not yet competent" - only your best result counts.</li>
        <li>Use the <a href="<?php echo html_escape(site_url('materials.php')); ?>">learning materials</a> to revise before retrying.</li>
        <li>Download your statement of results to share with your host employer or coordinator.</li>
      </ul>
    </div>
  </div>
  <?php render_page_footer(); ?>
</body>
</html>
