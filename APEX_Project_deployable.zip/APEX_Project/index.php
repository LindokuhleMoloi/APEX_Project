<?php
// index.php - Learner home: announcements, progress and the module drip path.

require_once __DIR__ . '/includes/app.php';
require_once __DIR__ . '/includes/portal.php';
require_once __DIR__ . '/includes/module_template.php';
app_start();

$isLoggedIn = is_user_logged_in();
$announcements = [];
$moduleCards = [];
$progressPercent = 0;
$activeRegistration = null;

if ($isLoggedIn) {
    $db = db_connect();
    $userId = (int) $_SESSION['user_id'];
    $announcements = portal_get_announcements($db, 3);
    $activeRegistration = portal_get_active_registration($db, $userId);
    $passed = portal_get_passed_modules($db, $userId);
    $completed = portal_get_completed_modules($db, $userId);
    $progressPercent = portal_overall_progress_percent($db, $userId);

    foreach (get_module_metadata() as $id => $module) {
        $unlocked = portal_is_module_unlocked($db, $userId, $id);
        $isPassed = isset($passed[$id]);
        $contentDone = isset($completed[$id]);

        if ($isPassed) {
            $state = 'Completed';
        } elseif ($unlocked) {
            $state = $contentDone ? 'Quiz outstanding' : 'Available';
        } else {
            $state = 'Locked';
        }

        $moduleCards[] = [
            'step' => $id,
            'title' => $module['title'],
            'description' => $module['overview'],
            'details' => $module['goal'],
            'enabled' => $unlocked,
            'passed' => $isPassed,
            'content_done' => $contentDone,
            'state' => $state,
            'best_percent' => $isPassed ? $passed[$id] : null,
        ];
    }

    $subjectLine = $activeRegistration
        ? $activeRegistration['name'] . ($activeRegistration['status'] !== 'Approved' ? ' (' . $activeRegistration['status'] . ')' : '')
        : 'No course registered yet';
    $_SESSION['subject'] = $activeRegistration['name'] ?? 'No Subject';
}
?>
<?php render_head('Home', ['js/index.js']); ?>
<body>
  <?php render_navigation(); ?>
  <div class="page-container">
    <?php render_flash_messages(); ?>
    <header>
      <div class="section-header">
        <div>
          <h1>Welcome to the <?php echo html_escape(APP_NAME); ?></h1>
          <?php if ($isLoggedIn): ?>
            <div class="subject-header">Your qualification: <strong><?php echo html_escape($subjectLine); ?></strong></div>
            <p>Hello, <?php echo html_escape($_SESSION['full_name'] ?? $_SESSION['username']); ?>! Ready to continue your learning path?</p>
          <?php else: ?>
            <p>Your gateway to SETA-accredited learnerships hosted by B-BBEE compliant South African employers.
               Log in to access your modules, learning materials, quizzes and documents.</p>
          <?php endif; ?>
        </div>
        <?php if ($isLoggedIn): ?>
          <a href="<?php echo html_escape(site_url('courses.php')); ?>" class="btn btn-primary">Open My Courses</a>
        <?php else: ?>
          <div class="hero-actions">
            <a href="<?php echo html_escape(site_url('login.php')); ?>" class="btn btn-primary">Login</a>
            <a href="<?php echo html_escape(site_url('register.php')); ?>" class="btn btn-secondary">Register as a learner</a>
          </div>
        <?php endif; ?>
      </div>
    </header>

    <?php if (!$isLoggedIn): ?>
      <div class="dashboard">
        <div class="main-content">
          <div class="course-card">
            <h2>What you get on the portal</h2>
            <div class="feature-grid">
              <div class="feature-item">
                <h3>&#128218; Structured modules</h3>
                <p>Six step-by-step modules from IT basics to cybersecurity, released one at a time so you master each topic.</p>
              </div>
              <div class="feature-item">
                <h3>&#128196; Learning materials</h3>
                <p>Download study guides, slides and exercises uploaded by your training provider - on any device.</p>
              </div>
              <div class="feature-item">
                <h3>&#9997;&#65039; Quizzes &amp; grades</h3>
                <p>Test yourself after every module, track your marks, and download your statement of results.</p>
              </div>
              <div class="feature-item">
                <h3>&#128228; Document uploads</h3>
                <p>Submit your certified ID copy, CV, proof of residence and assignments securely from the portal.</p>
              </div>
            </div>
          </div>
          <div class="course-card">
            <h2>Qualifications on offer</h2>
            <ul>
              <li><strong>End User Computing NQF3</strong> (SAQA 49077, MICT SETA) &ndash; workplace computer literacy and office productivity.</li>
              <li><strong>Software Development NQF4</strong> (SAQA 78964, MICT SETA) &ndash; programming, databases and web development foundations.</li>
            </ul>
            <p>Learnerships combine theory with practical workplace experience at your host employer, and support B-BBEE skills development goals.</p>
          </div>
        </div>
      </div>
    <?php else: ?>
      <?php if (!empty($announcements)): ?>
        <div class="announcement-strip">
          <?php foreach ($announcements as $announcement): ?>
            <div class="announcement-item">
              <div class="announcement-icon">&#128226;</div>
              <div>
                <strong><?php echo html_escape($announcement['title']); ?></strong>
                <p><?php echo nl2br(html_escape($announcement['body'])); ?></p>
                <span class="announcement-meta"><?php echo html_escape(date('d M Y', strtotime($announcement['created_at']))); ?></span>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>

      <div class="dashboard">
        <div class="main-content course-flow">
          <div class="course-card">
            <div class="section-header">
              <div>
                <h2>Course Drip Path</h2>
                <p>Modules unlock sequentially. Pass each exit quiz (<?php echo QUIZ_PASS_MARK; ?>%+) to unlock the next module.</p>
              </div>
              <span class="course-chip"><?php echo $progressPercent; ?>% complete</span>
            </div>

            <div class="progress-bar-bg overall-progress">
              <div class="progress-bar-fill" style="width: <?php echo $progressPercent; ?>%;"></div>
            </div>

            <?php foreach ($moduleCards as $module): ?>
              <article class="module-card<?php echo $module['enabled'] ? '' : ' module-locked'; ?><?php echo $module['passed'] ? ' module-complete' : ''; ?>" data-step="<?php echo $module['step']; ?>">
                <div class="module-header">
                  <div>
                    <h3 class="module-title">Module <?php echo $module['step']; ?>: <?php echo html_escape($module['title']); ?></h3>
                    <p class="module-description"><?php echo html_escape($module['description']); ?></p>
                  </div>
                  <div class="module-status">
                    <?php echo html_escape($module['state']); ?>
                    <?php if ($module['best_percent'] !== null): ?>
                      <span class="module-best">Best: <?php echo number_format((float) $module['best_percent'], 0); ?>%</span>
                    <?php endif; ?>
                  </div>
                </div>

                <div class="module-details">
                  <p><?php echo html_escape($module['details']); ?></p>
                </div>

                <div class="module-actions">
                  <a href="<?php echo $module['enabled'] ? html_escape(site_url('modules/module' . $module['step'] . '/index.php')) : html_escape(site_url('locked_module.php?module=' . $module['step'])); ?>" class="btn btn-soft<?php echo $module['enabled'] ? '' : ' btn-disabled-link'; ?>"><?php echo $module['enabled'] ? 'View module' : 'Module locked'; ?></a>
                  <a href="<?php echo $module['enabled'] ? html_escape(site_url('modules/module' . $module['step'] . '/quiz.php')) : html_escape(site_url('locked_module.php?module=' . $module['step'] . '&content=quiz')); ?>" class="btn <?php echo $module['passed'] ? 'btn-secondary' : 'btn-primary'; ?><?php echo $module['enabled'] ? '' : ' btn-disabled-link'; ?>"><?php echo $module['passed'] ? 'Retake quiz' : 'Start quiz'; ?></a>
                </div>
              </article>
            <?php endforeach; ?>
          </div>
        </div>

        <aside class="sidebar course-drip">
          <h3>Quick links</h3>
          <ul class="quick-links">
            <li><a href="<?php echo html_escape(site_url('materials.php')); ?>">&#128196; Download learning materials</a></li>
            <li><a href="<?php echo html_escape(site_url('documents.php')); ?>">&#128228; Upload my documents</a></li>
            <li><a href="<?php echo html_escape(site_url('grades.php')); ?>">&#127942; View my grades</a></li>
            <li><a href="<?php echo html_escape(site_url('quizzes.php')); ?>">&#9997;&#65039; All quizzes</a></li>
            <li><a href="<?php echo html_escape(site_url('profile.php')); ?>">&#128100; My profile</a></li>
          </ul>

          <h3>How the drip path works</h3>
          <p>Follow each step in order. Pass each module's exit quiz to unlock the next one.</p>
          <ul class="drip-list">
            <?php foreach ($moduleCards as $module): ?>
              <li class="drip-list-item<?php echo $module['passed'] ? ' drip-done' : ''; ?>">
                <span></span><strong>Module <?php echo $module['step']; ?></strong>
                <?php echo $module['passed'] ? 'completed' : ($module['enabled'] ? 'unlocked now' : 'unlocks after Module ' . ($module['step'] - 1)); ?>
              </li>
            <?php endforeach; ?>
          </ul>
        </aside>
      </div>
    <?php endif; ?>
  </div>
  <?php render_page_footer(); ?>
</body>
</html>
