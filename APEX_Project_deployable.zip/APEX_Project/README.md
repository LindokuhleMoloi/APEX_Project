# SS Learner Portal (APEX Project)

A complete student learning portal for **South African learnership programmes**, built for
SETA-accredited training hosted by B-BBEE compliant employers. Learners work through a
drip-released module path with quizzes, download learning materials, upload their
onboarding documents and assignments, and track their grades — while the training
provider manages enrollments, materials, document reviews, announcements and results
from an admin dashboard.

**Stack:** PHP 8+ (no framework, no Composer dependencies) · MySQL / MariaDB · vanilla JS + CSS.
Runs on XAMPP, cPanel shared hosting, or any LAMP server.

---

## Features

### Learner portal
| Area | What it does |
| --- | --- |
| **Registration & login** | Account creation with full name, cellphone, optional SA ID number (validated, 13 digits), POPIA consent, hashed passwords, CSRF protection on every form. |
| **Course enrollment** | Browse qualifications (NQF level, SAQA ID, credits, duration, SETA), request enrollment, and track Pending / Approved / Rejected status. |
| **Module drip path** | Six IT Foundations modules unlock sequentially: pass each module's exit quiz (60%+) to unlock the next. Progress is stored in the database, not the browser. |
| **Quizzes** | Server-side graded exit quizzes with unlimited retries, attempt history, per-question feedback on your last attempt, and best-result tracking. |
| **Learning materials** | Download study guides, slides and exercises published by the training provider — general, per-course and per-module. |
| **My Documents** | Upload certified ID copies, CVs, proof of residence, assignments and portfolio evidence; track review status; download or delete pending uploads. Onboarding checklist included. |
| **Grades** | Real module results, competency status, average best result, attempt log, and a downloadable **Statement of Results (CSV)**. |
| **Profile** | Update details, upload a profile photo, switch portal theme (default / soft / dark), change password. ID numbers are masked on screen. |
| **Announcements** | Programme news from the training provider on the home page. |

### Admin portal (training provider)
| Area | What it does |
| --- | --- |
| **Dashboard** | Live statistics (learners, pending registrations, documents to review, pass rate…), pending enrollment approvals, recent quiz activity, and admin account creation. |
| **Learners** | Search learners, view per-learner progress, results, registrations and documents; reset passwords. |
| **Materials** | Upload/publish learning materials (up to 50 MB) targeted at a course and module; delete outdated files. |
| **Documents** | Review learner uploads — approve or reject with a note the learner sees. |
| **Results** | Per-module statistics (attempts, average, pass rate) and a full attempt log with CSV export for SETA/programme reporting. |
| **Announcements** | Publish and remove announcements. |

### Security
- Passwords hashed with `password_hash()` (the installer also converts any legacy plain-text admin rows).
- Public admin self-registration **removed** — admins are created by an existing admin.
- CSRF tokens on all state-changing forms; sessions are HttpOnly + SameSite=Lax and regenerated at login.
- All SQL uses prepared statements.
- Uploads: extension whitelist, MIME sniff, size limits, randomised stored names, and the
  `uploads/` directory is blocked from direct web access — every download flows through
  `download.php`, which checks ownership/enrollment first.
- POPIA: explicit consent at registration, purpose-limited processing notices, masked ID numbers.

---

## Quick start (local / XAMPP)

1. Copy the project into your web root (e.g. `C:\xampp\htdocs\APEX_Project`).
2. Start Apache + MySQL.
3. Create the database — either:
   - import **`ss_portal.sql`** in phpMyAdmin, **or**
   - run **`php setup.php`** from the project folder (creates and seeds everything, and
     also *upgrades an existing v1 ss_portal database in place*).
4. Open `http://localhost/APEX_Project/`.

**Default admin login:** `admin` / `Admin@123` → log in at `admin_login.php` and change it immediately
(create a new admin on the dashboard, then remove the default one from the `admin` table).

## Configuration

The portal reads its configuration from environment variables, with XAMPP-friendly defaults:

| Variable | Default | Purpose |
| --- | --- | --- |
| `SS_PORTAL_DB_HOST` | `localhost` | Database host |
| `SS_PORTAL_DB_USER` | `root` | Database user |
| `SS_PORTAL_DB_PASS` | *(empty)* | Database password |
| `SS_PORTAL_DB_NAME` | `ss_portal` | Database name |
| `SS_PORTAL_APP_NAME` | `SS Learner Portal` | Branding shown in the UI |
| `SS_PORTAL_SETUP_KEY` | *(unset)* | When set, allows running `setup.php?key=...` over the web |

On cPanel, set these under *Software → MultiPHP INI Editor / Environment*, or in an
`.htaccess` `SetEnv` block. Without any configuration the defaults match a stock XAMPP install.

## Deployment checklist (shared hosting / cPanel)

1. Upload all files (or `git clone`) into `public_html/` (or a subfolder).
2. Create a MySQL database + user in cPanel and grant all privileges.
3. Set the `SS_PORTAL_DB_*` environment variables to the cPanel database credentials.
4. Run `php setup.php` via SSH/terminal — or set `SS_PORTAL_SETUP_KEY` and visit
   `setup.php?key=...` once, then **delete `setup.php`**.
5. Log in as the default admin, create your own admin account, change/remove the default.
6. Confirm HTTPS is enforced by your host (session cookies are marked Secure automatically when on HTTPS).
7. Check that `uploads/` is not directly browsable (the included `.htaccess` files handle this on Apache).

## Project structure

```
├── index.php                # Learner home: announcements, progress, drip path
├── login.php / register.php # Learner auth (POPIA consent, validation)
├── courses.php              # Qualifications + enrollment requests
├── materials.php            # Download learning materials
├── documents.php            # Upload/manage learner documents
├── grades.php               # Results + CSV statement of results
├── quizzes.php              # Quiz overview with best results
├── profile.php              # Details, avatar, theme, password
├── download.php             # Permission-checked file streaming
├── locked_module.php        # Drip-lock explainer page
├── admin_login.php          # Admin auth
├── dashboard.php            # Admin overview + registration approvals
├── admin_learners.php       # Learner management
├── admin_materials.php      # Material publishing
├── admin_documents.php      # Document review
├── admin_results.php        # Results + CSV export
├── admin_announcements.php  # Announcement publishing
├── setup.php                # Installer / upgrader (delete on production)
├── ss_portal.sql            # Fresh-install schema + seed data
├── includes/
│   ├── app.php              # Config, session, CSRF, uploads, layout helpers
│   ├── portal.php           # Domain layer (all DB access for portal features)
│   └── module_template.php  # Module content, quiz questions, page renderers
├── modules/module1..6/      # Thin wrappers: index.php (content) + quiz.php
├── assets/css|js/           # Stylesheet and progressive-enhancement JS
└── uploads/                 # materials/ documents/ avatars/ (web-blocked)
```

Project reports and process documentation (`SS_Portal_Project_Report.md`, workflow PDFs)
live in the repository root alongside the application.

## The learnership context

This portal supports learnerships under the South African skills development framework:

- **Qualifications** carry NQF levels, SAQA IDs, credits and the administering SETA
  (seeded: End User Computing NQF3 — SAQA 49077, and Software Development NQF4 —
  SAQA 78964, both MICT SETA; editable in the `subjects` table).
- **Host employers** earn B-BBEE skills development points and Section 12H tax incentives
  for hosting learners — the portal gives coordinators the records (enrollments, progress,
  results, documents) they need for that reporting.
- **POPIA** consent is captured at registration, and learner documents/ID numbers are
  access-controlled and masked.

## Development

```bash
# Syntax-check everything
find . -name '*.php' -not -path './docs/*' -exec php -l {} \;

# Run locally with the PHP built-in server (needs a running MySQL/MariaDB)
php -S localhost:8000
```

Runtime folders (`logs/`, `cache/`, `uploads/*`) are created automatically and git-ignored.
