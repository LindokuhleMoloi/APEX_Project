-- =====================================================================
-- SS Learner Portal - database schema (fresh install)
-- ---------------------------------------------------------------------
-- Import this file into MySQL / MariaDB (phpMyAdmin or CLI) to create
-- the full portal database, or run `php setup.php` which creates and
-- upgrades the same schema automatically.
--
-- Default admin login after import:  admin / Admin@123
-- CHANGE THIS PASSWORD IMMEDIATELY after the first login.
-- =====================================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE DATABASE IF NOT EXISTS `ss_portal` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `ss_portal`;

-- ---------------------------------------------------------------------
-- Portal administrators (training provider staff)
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin` (`username`, `password`) VALUES
('admin', '$2y$12$SAqz8e9SkGBy0CNDIe1v/uw9oHbzkIeNeJkjNUmx7SU0PfMGNNutC')
ON DUPLICATE KEY UPDATE `username` = `username`;

-- ---------------------------------------------------------------------
-- Learners
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `is_admin` tinyint(1) DEFAULT 0,
  `email` varchar(255) DEFAULT NULL,
  `full_name` varchar(150) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `id_number` varchar(13) DEFAULT NULL COMMENT 'South African ID number (POPIA-protected)',
  `avatar_path` varchar(255) DEFAULT NULL,
  `theme` varchar(20) NOT NULL DEFAULT 'default',
  `popia_consent` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ---------------------------------------------------------------------
-- Qualifications offered on the learnership programme
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `subjects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `code` varchar(20) DEFAULT NULL,
  `nqf_level` tinyint(4) DEFAULT NULL,
  `saqa_id` varchar(20) DEFAULT NULL,
  `credits` int(11) DEFAULT NULL,
  `duration_months` int(11) DEFAULT NULL,
  `seta` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `subjects` (`id`, `name`, `code`, `nqf_level`, `saqa_id`, `credits`, `duration_months`, `seta`, `description`) VALUES
(1, 'End User Computing NQF3', 'EUC-NQF3', 3, '49077', 130, 12, 'MICT SETA',
 'National Certificate: Information Technology: End User Computing. Builds confident, work-ready computer skills: office productivity tools, internet and email, file management and digital workplace literacy.'),
(2, 'Software Development NQF4', 'SD-NQF4', 4, '78964', 163, 12, 'MICT SETA',
 'Further Education and Training Certificate: Information Technology: Systems Development. Introduces programming logic, databases, web development and the software development life cycle.')
ON DUPLICATE KEY UPDATE
  `code` = VALUES(`code`), `nqf_level` = VALUES(`nqf_level`), `saqa_id` = VALUES(`saqa_id`),
  `credits` = VALUES(`credits`), `duration_months` = VALUES(`duration_months`),
  `seta` = VALUES(`seta`), `description` = VALUES(`description`);

-- ---------------------------------------------------------------------
-- Course enrollment requests (approved by an administrator)
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `registrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `status` enum('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
  `registration_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `email` varchar(255) DEFAULT NULL,
  `decided_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_subject` (`user_id`, `subject_id`),
  KEY `subject_id` (`subject_id`),
  CONSTRAINT `registrations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `registrations_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ---------------------------------------------------------------------
-- Module progress ("mark as read/complete") per learner
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `module_progress` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `module_number` tinyint(4) NOT NULL,
  `completed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_module` (`user_id`, `module_number`),
  CONSTRAINT `module_progress_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ---------------------------------------------------------------------
-- Exit-quiz attempts, graded server side
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `quiz_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `module_number` tinyint(4) NOT NULL,
  `score` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `percent` decimal(5,2) NOT NULL,
  `passed` tinyint(1) NOT NULL DEFAULT 0,
  `answers` text DEFAULT NULL,
  `attempted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_module` (`user_id`, `module_number`),
  CONSTRAINT `quiz_attempts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ---------------------------------------------------------------------
-- Learning materials uploaded by the training provider
-- (subject_id NULL = available to every learner; module_number NULL = general)
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `learning_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_id` int(11) DEFAULT NULL,
  `module_number` tinyint(4) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `file_path` varchar(255) NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `file_size` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `mime_type` varchar(100) DEFAULT NULL,
  `uploaded_by` varchar(50) DEFAULT NULL,
  `upload_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `subject_id` (`subject_id`),
  CONSTRAINT `learning_materials_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ---------------------------------------------------------------------
-- Learner document uploads (certified ID copies, CVs, assignments, ...)
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `doc_type` varchar(50) NOT NULL DEFAULT 'Other',
  `document_name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `original_name` varchar(255) DEFAULT NULL,
  `file_size` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `mime_type` varchar(100) DEFAULT NULL,
  `status` enum('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
  `review_note` varchar(255) DEFAULT NULL,
  `upload_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `reviewed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `documents_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ---------------------------------------------------------------------
-- Announcements from the training provider
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `announcements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `body` text NOT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `announcements` (`title`, `body`, `created_by`)
SELECT 'Welcome to the SS Learner Portal',
       'Welcome to your learnership journey! Work through the modules in order, download your learning materials from the Materials page, and upload your onboarding documents (certified ID copy, CV and proof of residence) under My Documents. Contact your training coordinator if you need help.',
       'admin'
WHERE NOT EXISTS (SELECT 1 FROM `announcements`);

COMMIT;
