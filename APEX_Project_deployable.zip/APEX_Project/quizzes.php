<?php
require_once __DIR__ . '/includes/app.php';
require_once __DIR__ . '/includes/portal.php';
require_once __DIR__ . '/includes/module_template.php';
app_start();
require_user();

$db = db_connect();
$userId = (int) $_SESSION['user_id'];

$moduleMeta = get_module_metadata();
$questions = get_quiz_questions();
$bestAttempts = portal_get_best_attempts($db, $userId);
?>
<?php render_head('Quizzes'); ?>
<body>
  <?php render_navigation(); ?>
  <div class="page-container">
    <?php render_flash_messages(); ?>
    <h1>Quizzes &amp; Practice</h1>
    <p>Each module ends with an exit quiz. Pass with <strong><?php echo QUIZ_PASS_MARK; ?>% or more</strong> to unlock the
       next module. You can retake quizzes as often as you like - your best result counts.</p>

    <div class="quiz-card">
      <?php foreach ($moduleMeta as $id => $module): ?>
        <?php
          $unlocked = portal_is_module_unlocked($db, $userId, $id);
          $best = $bestAttempts[$id] ?? null;
          $questionCount = count($questions[$id] ?? []);
        ?>
        <div class="quiz-card-item<?php echo $unlocked ? '' : ' quiz-item-locked'; ?>">
          <h3>Module <?php echo $id; ?> Quiz: <?php echo html_escape($module['title']); ?></h3>
          <p><?php echo $questionCount; ?> multiple-choice questions covering <?php echo html_escape(strtolower($module['title'])); ?>.</p>
          <p>
            <?php if ($best): ?>
              <strong>Best result:</strong> <?php echo number_format((float) $best['best_percent'], 0); ?>%
              (<?php echo (int) $best['attempts']; ?> attempt<?php echo (int) $best['attempts'] > 1 ? 's' : ''; ?>)
              <?php echo ((int) $best['passed']) === 1 ? '<span class="status-chip chip-approved">Passed</span>' : '<span class="status-chip chip-rejected">Not passed</span>'; ?>
            <?php elseif ($unlocked): ?>
              <strong>Status:</strong> Not attempted yet
            <?php else: ?>
              <strong>Status:</strong> &#128274; Locked &ndash; pass Module <?php echo $id - 1; ?> first
            <?php endif; ?>
          </p>
          <?php if ($unlocked): ?>
            <a href="<?php echo html_escape(site_url("modules/module{$id}/quiz.php")); ?>" class="btn btn-primary"><?php echo $best ? 'Retake quiz' : 'Start quiz'; ?></a>
          <?php else: ?>
            <a href="<?php echo html_escape(site_url('locked_module.php?module=' . $id . '&content=quiz')); ?>" class="btn btn-disabled-link">Locked</a>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </div>

    <div class="info-panel">
      <h2>Quiz Preparation Tips</h2>
      <ul>
        <li>Work through the module content and <a href="<?php echo html_escape(site_url('materials.php')); ?>">download the materials</a> before starting a quiz.</li>
        <li>Check the <a href="<?php echo html_escape(site_url('grades.php')); ?>">grades page</a> to find modules where you are not yet competent.</li>
        <li>Read every option before answering - there is no time limit, so take your time.</li>
      </ul>
    </div>
  </div>
  <?php render_page_footer(); ?>
</body>
</html>
