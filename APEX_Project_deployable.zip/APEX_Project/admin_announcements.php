<?php
// Admin: publish and remove announcements shown on the learner home page.

require_once __DIR__ . '/includes/app.php';
require_once __DIR__ . '/includes/portal.php';
app_start();
require_admin();

$db = db_connect();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        flash_set('error', 'Your session expired. Please try again.');
    } elseif (isset($_POST['create_announcement'])) {
        $title = sanitize_string($_POST['title'] ?? '');
        $body = trim($_POST['body'] ?? '');

        if (!$title || !$body) {
            flash_set('error', 'Please provide both a title and a message.');
        } elseif (portal_add_announcement($db, $title, $body, $_SESSION['admin_username'] ?? 'admin')) {
            flash_set('success', 'Announcement published. Learners will see it on their home page.');
        } else {
            flash_set('error', 'Could not publish the announcement.');
        }
    } elseif (isset($_POST['delete_announcement'])) {
        if (portal_delete_announcement($db, (int) $_POST['delete_announcement'])) {
            flash_set('success', 'Announcement removed.');
        } else {
            flash_set('error', 'Announcement not found.');
        }
    }

    header('Location: ' . site_url('admin_announcements.php'));
    exit;
}

$announcements = portal_get_announcements($db, 50);
?>
<?php render_head('Announcements'); ?>
<body class="admin-body">
  <?php render_admin_navigation(); ?>
  <div class="page-container">
    <?php render_flash_messages(); ?>
    <div class="section-header">
      <div>
        <h1>Announcements</h1>
        <p>Publish updates for learners - class schedules, stipend information, assessment dates and programme news.</p>
      </div>
    </div>

    <div class="course-card">
      <h2>New announcement</h2>
      <form method="post">
        <?php echo csrf_input_field(); ?>
        <div class="form-group">
          <label for="title">Title <span class="required">*</span></label>
          <input type="text" id="title" name="title" maxlength="200" required>
        </div>
        <div class="form-group">
          <label for="body">Message <span class="required">*</span></label>
          <textarea id="body" name="body" rows="4" required></textarea>
        </div>
        <button type="submit" name="create_announcement" value="1" class="btn btn-primary">Publish announcement</button>
      </form>
    </div>

    <div class="course-card">
      <h2>Published announcements (<?php echo count($announcements); ?>)</h2>
      <?php if (empty($announcements)): ?>
        <p>No announcements yet.</p>
      <?php else: ?>
        <?php foreach ($announcements as $announcement): ?>
          <div class="announcement-item announcement-admin">
            <div class="announcement-icon">&#128226;</div>
            <div class="announcement-content">
              <strong><?php echo html_escape($announcement['title']); ?></strong>
              <p><?php echo nl2br(html_escape($announcement['body'])); ?></p>
              <span class="announcement-meta">
                <?php echo html_escape(date('d M Y H:i', strtotime($announcement['created_at']))); ?>
                by <?php echo html_escape($announcement['created_by'] ?? 'admin'); ?>
              </span>
            </div>
            <form method="post" class="inline-form" onsubmit="return confirm('Remove this announcement?');">
              <?php echo csrf_input_field(); ?>
              <button type="submit" name="delete_announcement" value="<?php echo (int) $announcement['id']; ?>" class="btn btn-danger btn-small">Remove</button>
            </form>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>
  <?php render_page_footer(); ?>
</body>
</html>
